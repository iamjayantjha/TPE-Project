this.workbox = this.workbox || {}, this.workbox.routing = function(t, e) {
    "use strict";
    try {
        self["workbox:routing:5.0.0"] && _()
    } catch (t) {}
    const s = "GET",
        r = t => t && "object" == typeof t ? t : {
            handle: t
        };
    class n {
        constructor(t, e, n = s) {
            this.handler = r(e), this.match = t, this.method = n
        }
    }
    class o extends n {
        constructor(t, e, s) {
            super(({
                url: e
            }) => {
                const s = t.exec(e.href);
                if (s && (e.origin === location.origin || 0 === s.index)) return s.slice(1)
            }, e, s)
        }
    }
    class i {
        constructor() {
            this.t = new Map
        }
        get routes() {
            return this.t
        }
        addFetchListener() {
            self.addEventListener("fetch", t => {
                const {
                    request: e
                } = t, s = this.handleRequest({
                    request: e,
                    event: t
                });
                s && t.respondWith(s)
            })
        }
        addCacheListener() {
            self.addEventListener("message", t => {
                if (t.data && "CACHE_URLS" === t.data.type) {
                    const {
                        payload: e
                    } = t.data, s = Promise.all(e.urlsToCache.map(t => {
                        "string" == typeof t && (t = [t]);
                        const e = new Request(...t);
                        return this.handleRequest({
                            request: e
                        })
                    }));
                    t.waitUntil(s), t.ports && t.ports[0] && s.then(() => t.ports[0].postMessage(!0))
                }
            })
        }
        handleRequest({
            request: t,
            event: e
        }) {
            const s = new URL(t.url, location.href);
            if (!s.protocol.startsWith("http")) return;
            let r, {
                    params: n,
                    route: o
                } = this.findMatchingRoute({
                    url: s,
                    request: t,
                    event: e
                }),
                i = o && o.handler;
            if (!i && this.s && (i = this.s), i) {
                try {
                    r = i.handle({
                        url: s,
                        request: t,
                        event: e,
                        params: n
                    })
                } catch (t) {
                    r = Promise.reject(t)
                }
                return r instanceof Promise && this.o && (r = r.catch(r => this.o.handle({
                    url: s,
                    request: t,
                    event: e
                }))), r
            }
        }
        findMatchingRoute({
            url: t,
            request: e,
            event: s
        }) {
            const r = this.t.get(e.method) || [];
            for (const n of r) {
                let r, o = n.match({
                    url: t,
                    request: e,
                    event: s
                });
                if (o) return r = o, Array.isArray(o) && 0 === o.length ? r = void 0 : o.constructor === Object && 0 === Object.keys(o).length ? r = void 0 : "boolean" == typeof o && (r = void 0), {
                    route: n,
                    params: r
                }
            }
            return {}
        }
        setDefaultHandler(t) {
            this.s = r(t)
        }
        setCatchHandler(t) {
            this.o = r(t)
        }
        registerRoute(t) {
            this.t.has(t.method) || this.t.set(t.method, []), this.t.get(t.method).push(t)
        }
        unregisterRoute(t) {
            if (!this.t.has(t.method)) throw new e.WorkboxError("unregister-route-but-not-found-with-method", {
                method: t.method
            });
            const s = this.t.get(t.method).indexOf(t);
            if (!(s > -1)) throw new e.WorkboxError("unregister-route-route-not-registered");
            this.t.get(t.method).splice(s, 1)
        }
    }
    let u;
    const c = () => (u || ((u = new i).addFetchListener(), u.addCacheListener()), u);
    return t.NavigationRoute = class extends n {
        constructor(t, {
            allowlist: e = [/./],
            denylist: s = []
        } = {}) {
            super(t => this.i(t), t), this.u = e, this.h = s
        }
        i({
            url: t,
            request: e
        }) {
            if (e && "navigate" !== e.mode) return !1;
            const s = t.pathname + t.search;
            for (const t of this.h)
                if (t.test(s)) return !1;
            return !!this.u.some(t => t.test(s))
        }
    }, t.RegExpRoute = o, t.Route = n, t.Router = i, t.registerRoute = function(t, s, r) {
        let i;
        if ("string" == typeof t) {
            const e = new URL(t, location.href);
            i = new n(({
                url: t
            }) => t.href === e.href, s, r)
        } else if (t instanceof RegExp) i = new o(t, s, r);
        else if ("function" == typeof t) i = new n(t, s, r);
        else {
            if (!(t instanceof n)) throw new e.WorkboxError("unsupported-route-type", {
                moduleName: "workbox-routing",
                funcName: "registerRoute",
                paramName: "capture"
            });
            i = t
        }
        return c().registerRoute(i), i
    }, t.setCatchHandler = function(t) {
        c().setCatchHandler(t)
    }, t.setDefaultHandler = function(t) {
        c().setDefaultHandler(t)
    }, t
}({}, workbox.core._private);
//# sourceMappingURL=workbox-routing.prod.js.map