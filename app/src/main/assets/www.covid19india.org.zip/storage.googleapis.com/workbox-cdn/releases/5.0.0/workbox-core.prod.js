this.workbox = this.workbox || {}, this.workbox.core = function(e) {
    "use strict";
    try {
        self["workbox:core:5.0.0"] && _()
    } catch (e) {}
    const t = (e, ...t) => {
        let n = e;
        return t.length > 0 && (n += ` :: ${JSON.stringify(t)}`), n
    };
    class n extends Error {
        constructor(e, n) {
            super(t(e, n)), this.name = e, this.details = n
        }
    }
    const s = new Set;
    const r = {
            googleAnalytics: "googleAnalytics",
            precache: "precache-v2",
            prefix: "workbox",
            runtime: "runtime",
            suffix: "undefined" != typeof registration ? registration.scope : ""
        },
        i = e => [r.prefix, e, r.suffix].filter(e => e && e.length > 0).join("-"),
        a = {
            updateDetails: e => {
                (e => {
                    for (const t of Object.keys(r)) e(t)
                })(t => {
                    "string" == typeof e[t] && (r[t] = e[t])
                })
            },
            getGoogleAnalyticsName: e => e || i(r.googleAnalytics),
            getPrecacheName: e => e || i(r.precache),
            getPrefix: () => r.prefix,
            getRuntimeName: e => e || i(r.runtime),
            getSuffix: () => r.suffix
        };
    async function o() {
        for (const e of s) await e()
    }
    const c = e => {
            const t = new URL(String(e), location.href);
            return t.origin === location.origin ? t.pathname : t.href
        },
        u = (e, t) => e.filter(e => t in e),
        l = async ({
            cacheName: e,
            request: t,
            event: n,
            matchOptions: s,
            plugins: r = []
        }) => {
            const i = await self.caches.open(e),
                a = await h({
                    plugins: r,
                    request: t,
                    mode: "read"
                });
            let o = await i.match(a, s);
            for (const t of r)
                if ("cachedResponseWillBeUsed" in t) {
                    const r = t.cachedResponseWillBeUsed;
                    o = await r.call(t, {
                        cacheName: e,
                        event: n,
                        matchOptions: s,
                        cachedResponse: o,
                        request: a
                    })
                }
            return o
        },
        f = async ({
            request: e,
            response: t,
            event: n,
            plugins: s = []
        }) => {
            let r = t,
                i = !1;
            for (let t of s)
                if ("cacheWillUpdate" in t) {
                    i = !0;
                    const s = t.cacheWillUpdate;
                    if (!(r = await s.call(t, {
                            request: e,
                            response: r,
                            event: n
                        }))) break
                }
            return i || (r = r && 200 === r.status ? r : void 0), r || null
        },
        h = async ({
            request: e,
            mode: t,
            plugins: n = []
        }) => {
            const s = u(n, "cacheKeyWillBeUsed");
            let r = e;
            for (const e of s) "string" == typeof(r = await e.cacheKeyWillBeUsed.call(e, {
                mode: t,
                request: r
            })) && (r = new Request(r));
            return r
        },
        w = {
            put: async ({
                cacheName: e,
                request: t,
                response: s,
                event: r,
                plugins: i = [],
                matchOptions: a
            }) => {
                const w = await h({
                    plugins: i,
                    request: t,
                    mode: "write"
                });
                if (!s) throw new n("cache-put-with-no-response", {
                    url: c(w.url)
                });
                let d = await f({
                    event: r,
                    plugins: i,
                    response: s,
                    request: w
                });
                if (!d) return;
                const p = await self.caches.open(e),
                    g = u(i, "cacheDidUpdate");
                let y = g.length > 0 ? await l({
                    cacheName: e,
                    matchOptions: a,
                    request: w
                }) : null;
                try {
                    await p.put(w, d)
                } catch (e) {
                    throw "QuotaExceededError" === e.name && await o(), e
                }
                for (let t of g) await t.cacheDidUpdate.call(t, {
                    cacheName: e,
                    event: r,
                    oldResponse: y,
                    newResponse: d,
                    request: w
                })
            },
            match: l
        };
    let d, p;

    function g() {
        if (void 0 === p) {
            const e = new Response("");
            if ("body" in e) try {
                new Response(e.body), p = !0
            } catch (e) {
                p = !1
            }
            p = !1
        }
        return p
    }
    class y {
        constructor(e, t, {
            onupgradeneeded: n,
            onversionchange: s
        } = {}) {
            this.t = null, this.s = e, this.i = t, this.o = n, this.u = s || (() => this.close())
        }
        get db() {
            return this.t
        }
        async open() {
            if (!this.t) return this.t = await new Promise((e, t) => {
                let n = !1;
                setTimeout(() => {
                    n = !0, t(new Error("The open request was blocked and timed out"))
                }, this.OPEN_TIMEOUT);
                const s = indexedDB.open(this.s, this.i);
                s.onerror = (() => t(s.error)), s.onupgradeneeded = (e => {
                    n ? (s.transaction.abort(), s.result.close()) : "function" == typeof this.o && this.o(e)
                }), s.onsuccess = (() => {
                    const t = s.result;
                    n ? t.close() : (t.onversionchange = this.u.bind(this), e(t))
                })
            }), this
        }
        async getKey(e, t) {
            return (await this.getAllKeys(e, t, 1))[0]
        }
        async getAll(e, t, n) {
            return await this.getAllMatching(e, {
                query: t,
                count: n
            })
        }
        async getAllKeys(e, t, n) {
            return (await this.getAllMatching(e, {
                query: t,
                count: n,
                includeKeys: !0
            })).map(e => e.key)
        }
        async getAllMatching(e, {
            index: t,
            query: n = null,
            direction: s = "next",
            count: r,
            includeKeys: i = !1
        } = {}) {
            return await this.transaction([e], "readonly", (a, o) => {
                const c = a.objectStore(e),
                    u = t ? c.index(t) : c,
                    l = [],
                    f = u.openCursor(n, s);
                f.onsuccess = (() => {
                    const e = f.result;
                    e ? (l.push(i ? e : e.value), r && l.length >= r ? o(l) : e.continue()) : o(l)
                })
            })
        }
        async transaction(e, t, n) {
            return await this.open(), await new Promise((s, r) => {
                const i = this.t.transaction(e, t);
                i.onabort = (() => r(i.error)), i.oncomplete = (() => s()), n(i, e => s(e))
            })
        }
        async l(e, t, n, ...s) {
            return await this.transaction([t], n, (n, r) => {
                const i = n.objectStore(t),
                    a = i[e].apply(i, s);
                a.onsuccess = (() => r(a.result))
            })
        }
        close() {
            this.t && (this.t.close(), this.t = null)
        }
    }
    y.prototype.OPEN_TIMEOUT = 2e3;
    const m = {
        readonly: ["get", "count", "getKey", "getAll", "getAllKeys"],
        readwrite: ["add", "put", "clear", "delete"]
    };
    for (const [e, t] of Object.entries(m))
        for (const n of t) n in IDBObjectStore.prototype && (y.prototype[n] = async function(t, ...s) {
            return await this.l(n, t, e, ...s)
        });
    const q = {
        fetch: async ({
            request: e,
            fetchOptions: t,
            event: s,
            plugins: r = []
        }) => {
            if ("string" == typeof e && (e = new Request(e)), s instanceof FetchEvent && s.preloadResponse) {
                const e = await s.preloadResponse;
                if (e) return e
            }
            const i = u(r, "fetchDidFail"),
                a = i.length > 0 ? e.clone() : null;
            try {
                for (let t of r)
                    if ("requestWillFetch" in t) {
                        const n = t.requestWillFetch,
                            r = e.clone();
                        e = await n.call(t, {
                            request: r,
                            event: s
                        })
                    }
            } catch (e) {
                throw new n("plugin-error-request-will-fetch", {
                    thrownError: e
                })
            }
            let o = e.clone();
            try {
                let n;
                n = "navigate" === e.mode ? await fetch(e) : await fetch(e, t);
                for (const e of r) "fetchDidSucceed" in e && (n = await e.fetchDidSucceed.call(e, {
                    event: s,
                    request: o,
                    response: n
                }));
                return n
            } catch (e) {
                for (const t of i) await t.fetchDidFail.call(t, {
                    error: e,
                    event: s,
                    originalRequest: a.clone(),
                    request: o.clone()
                });
                throw e
            }
        }
    };

    function v(e) {
        return new Promise(t => setTimeout(t, e))
    }
    const x = 2e3;
    var R = Object.freeze({
        assert: null,
        cacheNames: a,
        cacheWrapper: w,
        canConstructReadableStream: function() {
            if (void 0 === d) try {
                new ReadableStream({
                    start() {}
                }), d = !0
            } catch (e) {
                d = !1
            }
            return d
        },
        canConstructResponseFromBodyStream: g,
        dontWaitFor: function(e) {
            e.then(() => {})
        },
        DBWrapper: y,
        Deferred: class {
            constructor() {
                this.promise = new Promise((e, t) => {
                    this.resolve = e, this.reject = t
                })
            }
        },
        deleteDatabase: async e => {
            await new Promise((t, n) => {
                const s = indexedDB.deleteDatabase(e);
                s.onerror = (() => {
                    n(s.error)
                }), s.onblocked = (() => {
                    n(new Error("Delete blocked"))
                }), s.onsuccess = (() => {
                    t()
                })
            })
        },
        executeQuotaErrorCallbacks: o,
        fetchWrapper: q,
        getFriendlyURL: c,
        logger: null,
        resultingClientExists: async function(e) {
            if (!e) return;
            let t = await self.clients.matchAll({
                type: "window"
            });
            const n = new Set(t.map(e => e.id));
            let s;
            const r = performance.now();
            for (; performance.now() - r < x && !(s = (t = await self.clients.matchAll({
                    type: "window"
                })).find(t => e ? t.id === e : !n.has(t.id)));) await v(100);
            return s
        },
        timeout: v,
        WorkboxError: n
    });
    const b = {
        get googleAnalytics() {
            return a.getGoogleAnalyticsName()
        },
        get precache() {
            return a.getPrecacheName()
        },
        get prefix() {
            return a.getPrefix()
        },
        get runtime() {
            return a.getRuntimeName()
        },
        get suffix() {
            return a.getSuffix()
        }
    };
    return e._private = R, e.cacheNames = b, e.clientsClaim = function() {
        self.addEventListener("activate", () => self.clients.claim())
    }, e.copyResponse = async function(e, t) {
        const n = e.clone(),
            s = {
                headers: new Headers(n.headers),
                status: n.status,
                statusText: n.statusText
            },
            r = t ? t(s) : s,
            i = g() ? n.body : await n.blob();
        return new Response(i, r)
    }, e.registerQuotaErrorCallback = function(e) {
        s.add(e)
    }, e.setCacheNameDetails = function(e) {
        a.updateDetails(e)
    }, e.skipWaiting = function() {
        self.addEventListener("install", () => self.skipWaiting())
    }, e
}({});
//# sourceMappingURL=workbox-core.prod.js.map