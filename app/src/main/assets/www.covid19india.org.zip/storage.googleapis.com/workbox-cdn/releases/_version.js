"use strict";
// @ts-ignore
try {
    self['workbox:routing:5.0.0'] && _();
} catch (e) {}