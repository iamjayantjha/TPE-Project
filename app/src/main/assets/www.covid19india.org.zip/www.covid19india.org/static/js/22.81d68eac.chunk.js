(this.webpackJsonpcovid19india = this.webpackJsonpcovid19india || []).push([
    [22], {
        132: function(e, t, n) {
            "use strict";
            n.d(t, "c", (function() {
                return a
            })), n.d(t, "e", (function() {
                return i
            })), n.d(t, "d", (function() {
                return c
            })), n.d(t, "f", (function() {
                return o
            })), n.d(t, "a", (function() {
                return r
            })), n.d(t, "b", (function() {
                return s
            })), n.d(t, "g", (function() {
                return l
            })), n.d(t, "h", (function() {
                return b
            }));
            var a = {
                    position: "absolute",
                    transform: "translate3d(-20rem, 0, 0)",
                    height: "100vh",
                    zIndex: -1
                },
                i = {
                    position: "absolute",
                    transform: "translate3d(10rem, 0, 0)"
                },
                c = {
                    opacity: 1,
                    position: "absolute",
                    height: "100vh",
                    top: 64,
                    zIndex: 999
                },
                o = {
                    opacity: 1,
                    position: "absolute",
                    height: "100vh",
                    top: 64,
                    zIndex: 999
                },
                r = {
                    opacity: 1,
                    marginTop: "7.5rem",
                    marginBottom: "30rem"
                },
                s = {
                    opacity: 0,
                    height: "0rem",
                    marginTop: "0rem",
                    marginBottom: "0rem"
                },
                l = {
                    opacity: 1,
                    transform: "translate3d(0, 0px, 0)",
                    height: 228
                },
                b = {
                    opacity: 0,
                    transform: "translate3d(0, 2px, 0)",
                    height: 0
                }
        },
        148: function(e) {
            e.exports = JSON.parse('{"english":"English","hindi":"\u0939\u093f\u0902\u0926\u0940","bengali":"\u09ac\u09be\u0982\u09b2\u09be","gujarati":"\u0a97\u0ac1\u0a9c\u0ab0\u0abe\u0aa4\u0ac0","kannada":"\u0c95\u0ca8\u0ccd\u0ca8\u0ca1","malayalam":"\u0d2e\u0d32\u0d2f\u0d3e\u0d33\u0d02","marathi":"\u092e\u0930\u093e\u0920\u0940","odiya":"\u0b13\u0b21\u0b3f\u0b06","punjabi":"\u0a2a\u0a70\u0a1c\u0a3e\u0a2c\u0a40","tamil":"\u0ba4\u0bae\u0bbf\u0bb4\u0bcd","telugu":"\u0c24\u0c46\u0c32\u0c41\u0c17\u0c41"}')
        },
        185: function(e, t, n) {},
        284: function(e, t, n) {
            "use strict";
            n.r(t);
            var a = n(47),
                i = (n(185), function() {
                    window.location.replace("https://blog.covid19india.org")
                }),
                c = n(98),
                o = n(132),
                r = n(148),
                s = n(2),
                l = n(242),
                b = n(243),
                d = n(244),
                j = n(245),
                u = n(246),
                h = n(247),
                O = n(288),
                p = n(48),
                f = n(97),
                m = n(240),
                v = n(282),
                x = n(241),
                g = n(187),
                w = n(19);

            function k(e) {
                var t = this,
                    n = e.pages,
                    a = e.setExpand,
                    i = e.darkMode,
                    o = e.windowSize,
                    r = Object(s.useRef)(null),
                    l = Object(O.a)().t,
                    b = Object(s.useCallback)((function() {
                        o.width >= 769 && a(!1)
                    }), [a, o.width]);
                return Object(w.jsxs)("div", {
                    className: "expand",
                    ref: r,
                    onMouseLeave: b,
                    children: [n.map((function(e, n) {
                        return !0 === e.showInNavbar ? Object(w.jsx)(p.b, Object(c.a)(Object(c.a)({
                            to: e.pageLink
                        }, o.width < 769 && {
                            onClick: a.bind(t, !1)
                        }), {}, {
                            children: Object(w.jsx)("span", Object(c.a)(Object(c.a)({}, N(e.pageLink, e.animationDelayForNavbar)), {}, {
                                children: l(e.displayName)
                            }))
                        }), n) : null
                    })), o.width < 769 && Object(w.jsx)(L, {
                        darkMode: i
                    }), Object(w.jsx)("div", {
                        className: "expand-bottom",
                        children: Object(w.jsx)("h5", {
                            children: l("A crowdsourced initiative.")
                        })
                    })]
                })
            }
            var y = function(e) {
                    var t, n = this,
                        i = e.pages,
                        u = e.showLanguageSwitcher,
                        h = e.setShowLanguageSwitcher,
                        y = Object(O.a)(),
                        N = y.i18n,
                        z = y.t,
                        C = Object.keys(r).includes(null === N || void 0 === N ? void 0 : N.language) ? null === N || void 0 === N ? void 0 : N.language : null === N || void 0 === N || null === (t = N.options) || void 0 === t ? void 0 : t.fallbackLng[0],
                        I = Object(s.useState)(!1),
                        M = Object(a.a)(I, 2),
                        E = M[0],
                        P = M[1],
                        T = Object(g.a)(!1);
                    Object(m.a)(E);
                    var A = Object(v.a)();
                    Object(x.a)((function() {
                        return P(!1)
                    }));
                    var B = Object(f.useTransition)(!0, {
                            from: {
                                opacity: 0
                            },
                            enter: {
                                opacity: 1
                            }
                        }),
                        J = Object(f.useTransition)(E, {
                            from: A.width < 769 ? o.d : o.c,
                            enter: A.width < 769 ? o.f : o.e,
                            leave: A.width < 769 ? o.d : o.c,
                            config: {
                                mass: 1,
                                tension: 210,
                                friction: 26
                            }
                        }),
                        F = Object(s.useCallback)((function() {
                            A.width >= 769 && P(!0)
                        }), [A.width]),
                        D = Object(s.useCallback)((function() {
                            E && P(!1), h(!u)
                        }), [E, u, P, h]);
                    return B((function(e, t) {
                        return Object(w.jsxs)(f.animated.div, {
                            className: "Navbar",
                            style: e,
                            children: [Object(w.jsx)("div", {
                                className: "navbar-left",
                                onClick: D,
                                children: r[C]
                            }), Object(w.jsx)("div", {
                                className: "navbar-middle",
                                children: Object(w.jsxs)(p.b, {
                                    to: "/",
                                    onClick: P.bind(n, !1),
                                    children: ["Covid19", Object(w.jsx)("span", {
                                        children: "India"
                                    })]
                                })
                            }), Object(w.jsxs)("div", Object(c.a)(Object(c.a)({
                                className: "navbar-right",
                                onMouseEnter: F
                            }, A.width < 769 && {
                                onClick: P.bind(n, !E)
                            }), {}, {
                                children: [A.width < 769 && Object(w.jsx)("span", {
                                    children: z(E ? "Close" : "Menu")
                                }), A.width >= 769 && Object(w.jsxs)(w.Fragment, {
                                    children: [Object(w.jsx)(p.b, {
                                        to: "/",
                                        children: Object(w.jsx)("span", {
                                            children: Object(w.jsx)(l.a, Object(c.a)({}, S("/")))
                                        })
                                    }), Object(w.jsx)(p.b, {
                                        to: "/blog",
                                        children: Object(w.jsx)("span", {
                                            children: Object(w.jsx)(b.a, Object(c.a)({}, S("/blog")))
                                        })
                                    }), Object(w.jsx)(p.b, {
                                        to: "/volunteers",
                                        children: Object(w.jsx)("span", {
                                            children: Object(w.jsx)(d.a, Object(c.a)({}, S("/volunteers")))
                                        })
                                    }), Object(w.jsx)(p.b, {
                                        to: "/about",
                                        children: Object(w.jsx)("span", {
                                            children: Object(w.jsx)(j.a, Object(c.a)({}, S("/about")))
                                        })
                                    }), Object(w.jsx)("span", {
                                        children: Object(w.jsx)(L, {
                                            darkMode: T
                                        })
                                    })]
                                })]
                            })), J((function(e, t) {
                                return t && Object(w.jsx)(f.animated.div, {
                                    style: e,
                                    children: Object(w.jsx)(k, {
                                        pages: i,
                                        setExpand: P,
                                        darkMode: T,
                                        windowSize: A
                                    })
                                })
                            }))]
                        })
                    }))
                },
                N = function(e, t) {
                    return {
                        className: "".concat(window.location.pathname === e ? "focused" : "")
                    }
                },
                S = function(e) {
                    return {
                        style: {
                            stroke: window.location.pathname === e ? "#4c75f2" : ""
                        }
                    }
                },
                L = function(e) {
                    var t = e.darkMode;
                    return Object(w.jsx)("div", {
                        className: "SunMoon",
                        onClick: t.toggle,
                        children: Object(w.jsx)("div", {
                            children: t.value ? Object(w.jsx)(u.a, {
                                color: "#ffc107"
                            }) : Object(w.jsx)(h.a, {})
                        })
                    })
                },
                z = n(24),
                C = n(5),
                I = Object(s.lazy)((function() {
                    return Object(z.l)((function() {
                        return Promise.all([n.e(4), n.e(7), n.e(17)]).then(n.bind(null, 281))
                    }))
                })),
                M = Object(s.lazy)((function() {
                    return Object(z.l)((function() {
                        return Promise.all([n.e(4), n.e(20)]).then(n.bind(null, 285))
                    }))
                })),
                E = Object(s.lazy)((function() {
                    return Object(z.l)((function() {
                        return Promise.all([n.e(4), n.e(23)]).then(n.bind(null, 248))
                    }))
                })),
                P = Object(s.lazy)((function() {
                    return Object(z.l)((function() {
                        return Promise.all([n.e(0), n.e(4), n.e(24)]).then(n.bind(null, 249))
                    }))
                })),
                T = Object(s.lazy)((function() {
                    return Object(z.l)((function() {
                        return Promise.all([n.e(0), n.e(29)]).then(n.bind(null, 250))
                    }))
                })),
                A = Object(s.lazy)((function() {
                    return Object(z.l)((function() {
                        return Promise.all([n.e(0), n.e(39)]).then(n.bind(null, 251))
                    }))
                }));
            t.default = function() {
                var e = Object(s.useState)(!1),
                    t = Object(a.a)(e, 2),
                    n = t[0],
                    c = t[1],
                    o = Object(C.h)(),
                    r = [{
                        pageLink: "/",
                        view: I,
                        displayName: "Home",
                        showInNavbar: !0
                    }, {
                        pageLink: "/blog",
                        view: i,
                        displayName: "Blog",
                        showInNavbar: !0
                    }, {
                        pageLink: "/volunteers",
                        view: M,
                        displayName: "Volunteers",
                        showInNavbar: !0
                    }, {
                        pageLink: "/about",
                        view: E,
                        displayName: "About",
                        showInNavbar: !0
                    }, {
                        pageLink: "/state/:stateCode",
                        view: P,
                        displayName: "State",
                        showInNavbar: !1
                    }];
                return Object(s.useEffect)((function() {
                    n && (document.documentElement.scrollTo({
                        top: 0,
                        behavior: "smooth"
                    }), document.body.scrollTo({
                        top: 0,
                        behavior: "smooth"
                    }))
                }), [n]), Object(w.jsxs)("div", {
                    className: "App",
                    children: [Object(w.jsx)(s.Suspense, {
                        fallback: Object(w.jsx)("div", {}),
                        children: Object(w.jsx)(T, {
                            showLanguageSwitcher: n,
                            setShowLanguageSwitcher: c
                        })
                    }), Object(w.jsx)(y, {
                        pages: r,
                        showLanguageSwitcher: n,
                        setShowLanguageSwitcher: c
                    }), Object(w.jsx)(A, {}), Object(w.jsx)(s.Suspense, {
                        fallback: Object(w.jsx)("div", {}),
                        children: Object(w.jsxs)(C.d, {
                            location: o,
                            children: [r.map((function(e, t) {
                                return Object(w.jsx)(C.b, {
                                    exact: !0,
                                    path: e.pageLink,
                                    render: function(t) {
                                        t.match;
                                        return Object(w.jsx)(e.view, {})
                                    }
                                }, t)
                            })), Object(w.jsx)(C.a, {
                                to: "/"
                            })]
                        })
                    })]
                })
            }
        }
    }
]);
//# sourceMappingURL=22.81d68eac.chunk.js.map