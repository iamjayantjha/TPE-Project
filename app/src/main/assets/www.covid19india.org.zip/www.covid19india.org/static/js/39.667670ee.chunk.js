(this.webpackJsonpcovid19india = this.webpackJsonpcovid19india || []).push([
    [39], {
        251: function(e, t, i) {
            "use strict";
            i.r(t);
            var s = i(95),
                a = i(288),
                n = i(19);
            t.default = function(e) {
                var t = Object(a.a)().t;
                return Object(n.jsx)("div", {
                    className: "Banner fadeInDown",
                    style: {
                        animationDelay: "0.4s"
                    },
                    children: Object(n.jsxs)("div", {
                        className: "wrapper",
                        children: [Object(n.jsx)("div", {
                            className: "alert-icon",
                            children: Object(n.jsx)(s.a, {
                                size: 16
                            })
                        }), Object(n.jsxs)("div", {
                            className: "content",
                            children: [t("After keeping you updated with Covid-19 information for the last 18 months, we will be stopping our operations on 31st October, 2021."), " "]
                        }), Object(n.jsxs)("a", {
                            href: "https://blog.covid19india.org/2021/08/07/end",
                            rel: "noreferrer",
                            target: "_blank",
                            children: [t("Read the full blog post"), Object(n.jsx)("div", {
                                className: "arrow-right-icon",
                                children: Object(n.jsx)(s.c, {
                                    size: 16
                                })
                            })]
                        })]
                    })
                })
            }
        }
    }
]);
//# sourceMappingURL=39.667670ee.chunk.js.map