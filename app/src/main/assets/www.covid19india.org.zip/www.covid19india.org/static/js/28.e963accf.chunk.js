(this.webpackJsonpcovid19india = this.webpackJsonpcovid19india || []).push([
    [28], {
        289: function(e, t, n) {
            "use strict";
            n.r(t);
            var a = n(47),
                c = n(99),
                s = n(24),
                r = n(95),
                i = n(2),
                o = n(288),
                l = n(19),
                d = Object(i.lazy)((function() {
                    return Object(s.l)((function() {
                        return n.e(21).then(n.bind(null, 283))
                    }))
                })),
                u = function(e) {
                    var t = e.lastUpdatedDate,
                        n = e.newUpdate,
                        a = e.isTimelineMode,
                        u = e.setIsTimelineMode,
                        j = e.showUpdates,
                        b = e.date,
                        f = e.setDate,
                        O = e.dates,
                        p = e.setNewUpdate,
                        h = e.setShowUpdates,
                        m = Object(o.a)().t,
                        v = Object(i.useMemo)((function() {
                            var e = [];
                            return [0, 0, 0].map((function(t, n) {
                                return e.push({
                                    animationDelay: "".concat(500 + 250 * n, "ms")
                                }), null
                            })), e
                        }), []),
                        x = Object(i.useCallback)((function() {
                            u(!0), j && h(!j)
                        }), [u, h, j]),
                        g = Object(i.useCallback)((function() {
                            j || p(!1), h(!j)
                        }), [j, h, p]);
                    return Object(l.jsxs)("div", {
                        className: "ActionsPanel",
                        children: [Object(l.jsxs)("div", {
                            className: "actions",
                            style: {
                                opacity: a ? 0 : 1,
                                transform: "perspective(600px) rotateX(".concat(a ? 90 : 0, "deg)"),
                                pointerEvents: a ? "none" : ""
                            },
                            children: [Object(l.jsx)("h5", {
                                className: "fadeInUp",
                                style: v[0],
                                children: "".concat(Object(s.c)(t, "dd MMM, p"), " ").concat(m("IST"))
                            }), Object(l.jsxs)("div", {
                                className: "bell-icon fadeInUp",
                                style: v[1],
                                onClick: g,
                                children: [j ? Object(l.jsx)(r.f, {
                                    size: 15
                                }) : Object(l.jsx)(r.e, {
                                    size: 15
                                }), n && Object(l.jsx)("div", {
                                    className: "indicator"
                                })]
                            }), Object(l.jsx)(c.a, {
                                message: "Timeline",
                                hold: !0,
                                children: Object(l.jsx)("div", {
                                    className: "timeline-icon fadeInUp",
                                    onClick: x,
                                    style: v[2],
                                    children: Object(l.jsx)(r.o, {})
                                })
                            })]
                        }), a && Object(l.jsx)(i.Suspense, {
                            fallback: Object(l.jsx)("div", {}),
                            children: Object(l.jsx)(d, {
                                date: b,
                                setDate: f,
                                dates: O,
                                isTimelineMode: a,
                                setIsTimelineMode: u
                            })
                        })]
                    })
                },
                j = n(10),
                b = n(199),
                f = n(91),
                O = n.n(f),
                p = n(197),
                h = n(110),
                m = Object(i.lazy)((function() {
                    return Object(s.l)((function() {
                        return n.e(45).then(n.bind(null, 258))
                    }))
                })),
                v = function(e) {
                    var t = e.date,
                        n = e.setDate,
                        c = e.dates,
                        r = e.lastUpdatedDate,
                        o = Object(i.useState)(!1),
                        d = Object(a.a)(o, 2),
                        f = d[0],
                        O = d[1],
                        v = Object(p.a)("newUpdate", !1),
                        x = Object(a.a)(v, 2),
                        g = x[0],
                        y = x[1],
                        U = Object(p.a)("lastViewedLog", 0),
                        w = Object(a.a)(U, 2),
                        k = w[0],
                        M = w[1],
                        S = Object(i.useState)(!1),
                        D = Object(a.a)(S, 2),
                        N = D[0],
                        T = D[1],
                        I = Object(h.a)("".concat(j.a, "/updatelog/log.json"), s.b, {
                            refreshInterval: j.b
                        }).data;
                    Object(i.useEffect)((function() {
                        if (void 0 !== I) {
                            var e = 1e3 * I.slice().reverse()[0].timestamp;
                            e !== k && (y(!0), M(e))
                        }
                    }), [k, I, M, y]);
                    var C = Object(i.useMemo)((function() {
                        return Object(s.d)(Object(b.a)([k, r].filter((function(e) {
                            return e
                        })).map((function(e) {
                            return Object(s.k)(e)
                        }))))
                    }), [k, r]);
                    return Object(l.jsxs)(l.Fragment, {
                        children: [Object(l.jsx)(u, {
                            lastUpdatedDate: C,
                            newUpdate: g,
                            isTimelineMode: N,
                            setIsTimelineMode: T,
                            showUpdates: f,
                            date: t,
                            setDate: n,
                            dates: c,
                            setNewUpdate: y,
                            setShowUpdates: O
                        }), f && Object(l.jsx)(i.Suspense, {
                            fallback: Object(l.jsx)("div", {}),
                            children: Object(l.jsx)(m, {
                                updates: I
                            })
                        })]
                    })
                },
                x = function(e, t) {
                    return !!O()(t.date, e.date) && (!!O()(t.lastUpdatedDate, e.lastUpdatedDate) && !!O()(t.dates, e.dates))
                };
            t.default = Object(i.memo)(v, x)
        },
        91: function(e, t, n) {
            "use strict";
            e.exports = function e(t, n) {
                if (t === n) return !0;
                if (t && n && "object" == typeof t && "object" == typeof n) {
                    if (t.constructor !== n.constructor) return !1;
                    var a, c, s;
                    if (Array.isArray(t)) {
                        if ((a = t.length) != n.length) return !1;
                        for (c = a; 0 !== c--;)
                            if (!e(t[c], n[c])) return !1;
                        return !0
                    }
                    if (t.constructor === RegExp) return t.source === n.source && t.flags === n.flags;
                    if (t.valueOf !== Object.prototype.valueOf) return t.valueOf() === n.valueOf();
                    if (t.toString !== Object.prototype.toString) return t.toString() === n.toString();
                    if ((a = (s = Object.keys(t)).length) !== Object.keys(n).length) return !1;
                    for (c = a; 0 !== c--;)
                        if (!Object.prototype.hasOwnProperty.call(n, s[c])) return !1;
                    for (c = a; 0 !== c--;) {
                        var r = s[c];
                        if (!e(t[r], n[r])) return !1
                    }
                    return !0
                }
                return t !== t && n !== n
            }
        },
        99: function(e, t, n) {
            "use strict";
            var a = n(98),
                c = n(128),
                s = n(2),
                r = (n(118), n(119), n(19));
            t.a = function(e) {
                var t = e.children,
                    n = e.message,
                    i = e.hold,
                    o = void 0 !== i && i,
                    l = e.childProps,
                    d = void 0 === l ? {} : l,
                    u = Object(s.useCallback)((function(e) {
                        return e.stopPropagation()
                    }), []);
                return Object(r.jsx)(c.a, {
                    className: "Tooltip",
                    content: "string" === typeof n ? Object(r.jsx)("p", {
                        className: "message",
                        dangerouslySetInnerHTML: {
                            __html: n.trim().split("\n").map((function(e) {
                                return "<div>".concat(e, "</div>")
                            })).join("")
                        }
                    }) : n,
                    arrow: !1,
                    animation: "shift-away",
                    touch: !o || ["hold", 300],
                    children: Object(r.jsx)("div", Object(a.a)(Object(a.a)({
                        onClick: u
                    }, d), {}, {
                        children: t
                    }))
                })
            }
        }
    }
]);
//# sourceMappingURL=28.e963accf.chunk.js.map