(this.webpackJsonpcovid19india = this.webpackJsonpcovid19india || []).push([
    [1], {
        103: function(t, n, e) {
            "use strict";
            e.d(n, "b", (function() {
                return _t
            })), e.d(n, "a", (function() {
                return S
            }));
            var r, i, a = e(223),
                o = e(252),
                u = 0,
                c = 0,
                s = 0,
                l = 0,
                f = 0,
                h = 0,
                p = "object" === typeof performance && performance.now ? performance : Date,
                d = "object" === typeof window && window.requestAnimationFrame ? window.requestAnimationFrame.bind(window) : function(t) {
                    setTimeout(t, 17)
                };

            function v() {
                return f || (d(g), f = p.now() + h)
            }

            function g() {
                f = 0
            }

            function y() {
                this._call = this._time = this._next = null
            }

            function m(t, n, e) {
                var r = new y;
                return r.restart(t, n, e), r
            }

            function w() {
                f = (l = p.now()) + h, u = c = 0;
                try {
                    ! function() {
                        v(), ++u;
                        for (var t, n = r; n;)(t = f - n._time) >= 0 && n._call.call(void 0, t), n = n._next;
                        --u
                    }()
                } finally {
                    u = 0,
                        function() {
                            var t, n, e = r,
                                a = 1 / 0;
                            for (; e;) e._call ? (a > e._time && (a = e._time), t = e, e = e._next) : (n = e._next, e._next = null, e = t ? t._next = n : r = n);
                            i = t, _(a)
                        }(), f = 0
                }
            }

            function b() {
                var t = p.now(),
                    n = t - l;
                n > 1e3 && (h -= n, l = t)
            }

            function _(t) {
                u || (c && (c = clearTimeout(c)), t - f > 24 ? (t < 1 / 0 && (c = setTimeout(w, t - p.now() - h)), s && (s = clearInterval(s))) : (s || (l = p.now(), s = setInterval(b, 1e3)), u = 1, d(w)))
            }
            y.prototype = m.prototype = {
                constructor: y,
                restart: function(t, n, e) {
                    if ("function" !== typeof t) throw new TypeError("callback is not a function");
                    e = (null == e ? v() : +e) + (null == n ? 0 : +n), this._next || i === this || (i ? i._next = this : r = this, i = this), this._call = t, this._time = e, _()
                },
                stop: function() {
                    this._call && (this._call = null, this._time = 1 / 0, _())
                }
            };
            var x = function(t, n, e) {
                    var r = new y;
                    return n = null == n ? 0 : +n, r.restart((function(e) {
                        r.stop(), t(e + n)
                    }), n, e), r
                },
                M = Object(o.a)("start", "end", "cancel", "interrupt"),
                k = [],
                A = function(t, n, e, r, i, a) {
                    var o = t.__transition;
                    if (o) {
                        if (e in o) return
                    } else t.__transition = {};
                    ! function(t, n, e) {
                        var r, i = t.__transition;

                        function a(t) {
                            e.state = 1, e.timer.restart(o, e.delay, e.time), e.delay <= t && o(t - e.delay)
                        }

                        function o(a) {
                            var s, l, f, h;
                            if (1 !== e.state) return c();
                            for (s in i)
                                if ((h = i[s]).name === e.name) {
                                    if (3 === h.state) return x(o);
                                    4 === h.state ? (h.state = 6, h.timer.stop(), h.on.call("interrupt", t, t.__data__, h.index, h.group), delete i[s]) : +s < n && (h.state = 6, h.timer.stop(), h.on.call("cancel", t, t.__data__, h.index, h.group), delete i[s])
                                }
                            if (x((function() {
                                    3 === e.state && (e.state = 4, e.timer.restart(u, e.delay, e.time), u(a))
                                })), e.state = 2, e.on.call("start", t, t.__data__, e.index, e.group), 2 === e.state) {
                                for (e.state = 3, r = new Array(f = e.tween.length), s = 0, l = -1; s < f; ++s)(h = e.tween[s].value.call(t, t.__data__, e.index, e.group)) && (r[++l] = h);
                                r.length = l + 1
                            }
                        }

                        function u(n) {
                            for (var i = n < e.duration ? e.ease.call(null, n / e.duration) : (e.timer.restart(c), e.state = 5, 1), a = -1, o = r.length; ++a < o;) r[a].call(t, i);
                            5 === e.state && (e.on.call("end", t, t.__data__, e.index, e.group), c())
                        }

                        function c() {
                            for (var r in e.state = 6, e.timer.stop(), delete i[n], i) return;
                            delete t.__transition
                        }
                        i[n] = e, e.timer = m(a, 0, e.time)
                    }(t, e, {
                        name: n,
                        index: r,
                        group: i,
                        on: M,
                        tween: k,
                        time: a.time,
                        delay: a.delay,
                        duration: a.duration,
                        ease: a.ease,
                        timer: null,
                        state: 0
                    })
                };

            function N(t, n) {
                var e = O(t, n);
                if (e.state > 0) throw new Error("too late; already scheduled");
                return e
            }

            function j(t, n) {
                var e = O(t, n);
                if (e.state > 3) throw new Error("too late; already running");
                return e
            }

            function O(t, n) {
                var e = t.__transition;
                if (!e || !(e = e[n])) throw new Error("transition not found");
                return e
            }
            var E, S = function(t, n) {
                    var e, r, i, a = t.__transition,
                        o = !0;
                    if (a) {
                        for (i in n = null == n ? null : n + "", a)(e = a[i]).name === n ? (r = e.state > 2 && e.state < 5, e.state = 6, e.timer.stop(), e.on.call(r ? "interrupt" : "cancel", t, t.__data__, e.index, e.group), delete a[i]) : o = !1;
                        o && delete t.__transition
                    }
                },
                C = e(50),
                q = e(138),
                P = 180 / Math.PI,
                T = {
                    translateX: 0,
                    translateY: 0,
                    rotate: 0,
                    skewX: 0,
                    scaleX: 1,
                    scaleY: 1
                },
                X = function(t, n, e, r, i, a) {
                    var o, u, c;
                    return (o = Math.sqrt(t * t + n * n)) && (t /= o, n /= o), (c = t * e + n * r) && (e -= t * c, r -= n * c), (u = Math.sqrt(e * e + r * r)) && (e /= u, r /= u, c /= u), t * r < n * e && (t = -t, n = -n, c = -c, o = -o), {
                        translateX: i,
                        translateY: a,
                        rotate: Math.atan2(n, t) * P,
                        skewX: Math.atan(c) * P,
                        scaleX: o,
                        scaleY: u
                    }
                };

            function L(t, n, e, r) {
                function i(t) {
                    return t.length ? t.pop() + " " : ""
                }
                return function(a, o) {
                    var u = [],
                        c = [];
                    return a = t(a), o = t(o),
                        function(t, r, i, a, o, u) {
                            if (t !== i || r !== a) {
                                var c = o.push("translate(", null, n, null, e);
                                u.push({
                                    i: c - 4,
                                    x: Object(q.a)(t, i)
                                }, {
                                    i: c - 2,
                                    x: Object(q.a)(r, a)
                                })
                            } else(i || a) && o.push("translate(" + i + n + a + e)
                        }(a.translateX, a.translateY, o.translateX, o.translateY, u, c),
                        function(t, n, e, a) {
                            t !== n ? (t - n > 180 ? n += 360 : n - t > 180 && (t += 360), a.push({
                                i: e.push(i(e) + "rotate(", null, r) - 2,
                                x: Object(q.a)(t, n)
                            })) : n && e.push(i(e) + "rotate(" + n + r)
                        }(a.rotate, o.rotate, u, c),
                        function(t, n, e, a) {
                            t !== n ? a.push({
                                i: e.push(i(e) + "skewX(", null, r) - 2,
                                x: Object(q.a)(t, n)
                            }) : n && e.push(i(e) + "skewX(" + n + r)
                        }(a.skewX, o.skewX, u, c),
                        function(t, n, e, r, a, o) {
                            if (t !== e || n !== r) {
                                var u = a.push(i(a) + "scale(", null, ",", null, ")");
                                o.push({
                                    i: u - 4,
                                    x: Object(q.a)(t, e)
                                }, {
                                    i: u - 2,
                                    x: Object(q.a)(n, r)
                                })
                            } else 1 === e && 1 === r || a.push(i(a) + "scale(" + e + "," + r + ")")
                        }(a.scaleX, a.scaleY, o.scaleX, o.scaleY, u, c), a = o = null,
                        function(t) {
                            for (var n, e = -1, r = c.length; ++e < r;) u[(n = c[e]).i] = n.x(t);
                            return u.join("")
                        }
                }
            }
            var R = L((function(t) {
                    var n = new("function" === typeof DOMMatrix ? DOMMatrix : WebKitCSSMatrix)(t + "");
                    return n.isIdentity ? T : X(n.a, n.b, n.c, n.d, n.e, n.f)
                }), "px, ", "px)", "deg)"),
                D = L((function(t) {
                    return null == t ? T : (E || (E = document.createElementNS("http://www.w3.org/2000/svg", "g")), E.setAttribute("transform", t), (t = E.transform.baseVal.consolidate()) ? (t = t.matrix, X(t.a, t.b, t.c, t.d, t.e, t.f)) : T)
                }), ", ", ")", ")"),
                z = e(164);

            function I(t, n) {
                var e, r;
                return function() {
                    var i = j(this, t),
                        a = i.tween;
                    if (a !== e)
                        for (var o = 0, u = (r = e = a).length; o < u; ++o)
                            if (r[o].name === n) {
                                (r = r.slice()).splice(o, 1);
                                break
                            }
                    i.tween = r
                }
            }

            function $(t, n, e) {
                var r, i;
                if ("function" !== typeof e) throw new Error;
                return function() {
                    var a = j(this, t),
                        o = a.tween;
                    if (o !== r) {
                        i = (r = o).slice();
                        for (var u = {
                                name: n,
                                value: e
                            }, c = 0, s = i.length; c < s; ++c)
                            if (i[c].name === n) {
                                i[c] = u;
                                break
                            }
                        c === s && i.push(u)
                    }
                    a.tween = i
                }
            }

            function H(t, n, e) {
                var r = t._id;
                return t.each((function() {
                        var t = j(this, r);
                        (t.value || (t.value = {}))[n] = e.apply(this, arguments)
                    })),
                    function(t) {
                        return O(t, r).value[n]
                    }
            }
            var B = e(296),
                Y = e(227),
                V = e(202),
                F = function(t, n) {
                    var e;
                    return ("number" === typeof n ? q.a : n instanceof B.a ? Y.a : (e = Object(B.a)(n)) ? (n = e, Y.a) : V.a)(t, n)
                };

            function U(t) {
                return function() {
                    this.removeAttribute(t)
                }
            }

            function J(t) {
                return function() {
                    this.removeAttributeNS(t.space, t.local)
                }
            }

            function G(t, n, e) {
                var r, i, a = e + "";
                return function() {
                    var o = this.getAttribute(t);
                    return o === a ? null : o === r ? i : i = n(r = o, e)
                }
            }

            function K(t, n, e) {
                var r, i, a = e + "";
                return function() {
                    var o = this.getAttributeNS(t.space, t.local);
                    return o === a ? null : o === r ? i : i = n(r = o, e)
                }
            }

            function W(t, n, e) {
                var r, i, a;
                return function() {
                    var o, u, c = e(this);
                    if (null != c) return (o = this.getAttribute(t)) === (u = c + "") ? null : o === r && u === i ? a : (i = u, a = n(r = o, c));
                    this.removeAttribute(t)
                }
            }

            function Z(t, n, e) {
                var r, i, a;
                return function() {
                    var o, u, c = e(this);
                    if (null != c) return (o = this.getAttributeNS(t.space, t.local)) === (u = c + "") ? null : o === r && u === i ? a : (i = u, a = n(r = o, c));
                    this.removeAttributeNS(t.space, t.local)
                }
            }

            function Q(t, n) {
                return function(e) {
                    this.setAttribute(t, n.call(this, e))
                }
            }

            function tt(t, n) {
                return function(e) {
                    this.setAttributeNS(t.space, t.local, n.call(this, e))
                }
            }

            function nt(t, n) {
                var e, r;

                function i() {
                    var i = n.apply(this, arguments);
                    return i !== r && (e = (r = i) && tt(t, i)), e
                }
                return i._value = n, i
            }

            function et(t, n) {
                var e, r;

                function i() {
                    var i = n.apply(this, arguments);
                    return i !== r && (e = (r = i) && Q(t, i)), e
                }
                return i._value = n, i
            }

            function rt(t, n) {
                return function() {
                    N(this, t).delay = +n.apply(this, arguments)
                }
            }

            function it(t, n) {
                return n = +n,
                    function() {
                        N(this, t).delay = n
                    }
            }

            function at(t, n) {
                return function() {
                    j(this, t).duration = +n.apply(this, arguments)
                }
            }

            function ot(t, n) {
                return n = +n,
                    function() {
                        j(this, t).duration = n
                    }
            }

            function ut(t, n) {
                if ("function" !== typeof n) throw new Error;
                return function() {
                    j(this, t).ease = n
                }
            }
            var ct = e(137);

            function st(t, n, e) {
                var r, i, a = function(t) {
                    return (t + "").trim().split(/^|\s+/).every((function(t) {
                        var n = t.indexOf(".");
                        return n >= 0 && (t = t.slice(0, n)), !t || "start" === t
                    }))
                }(n) ? N : j;
                return function() {
                    var o = a(this, t),
                        u = o.on;
                    u !== r && (i = (r = u).copy()).on(n, e), o.on = i
                }
            }
            var lt = e(163),
                ft = e(200),
                ht = a.b.prototype.constructor,
                pt = e(201);

            function dt(t) {
                return function() {
                    this.style.removeProperty(t)
                }
            }

            function vt(t, n, e) {
                return function(r) {
                    this.style.setProperty(t, n.call(this, r), e)
                }
            }

            function gt(t, n, e) {
                var r, i;

                function a() {
                    var a = n.apply(this, arguments);
                    return a !== i && (r = (i = a) && vt(t, a, e)), r
                }
                return a._value = n, a
            }

            function yt(t) {
                return function(n) {
                    this.textContent = t.call(this, n)
                }
            }

            function mt(t) {
                var n, e;

                function r() {
                    var r = t.apply(this, arguments);
                    return r !== e && (n = (e = r) && yt(r)), n
                }
                return r._value = t, r
            }
            var wt = 0;

            function bt(t, n, e, r) {
                this._groups = t, this._parents = n, this._name = e, this._id = r
            }

            function _t(t) {
                return Object(a.b)().transition(t)
            }

            function xt() {
                return ++wt
            }
            var Mt = a.b.prototype;
            bt.prototype = _t.prototype = Object(C.a)({
                constructor: bt,
                select: function(t) {
                    var n = this._name,
                        e = this._id;
                    "function" !== typeof t && (t = Object(lt.a)(t));
                    for (var r = this._groups, i = r.length, a = new Array(i), o = 0; o < i; ++o)
                        for (var u, c, s = r[o], l = s.length, f = a[o] = new Array(l), h = 0; h < l; ++h)(u = s[h]) && (c = t.call(u, u.__data__, h, s)) && ("__data__" in u && (c.__data__ = u.__data__), f[h] = c, A(f[h], n, e, h, f, O(u, e)));
                    return new bt(a, this._parents, n, e)
                },
                selectAll: function(t) {
                    var n = this._name,
                        e = this._id;
                    "function" !== typeof t && (t = Object(ft.a)(t));
                    for (var r = this._groups, i = r.length, a = [], o = [], u = 0; u < i; ++u)
                        for (var c, s = r[u], l = s.length, f = 0; f < l; ++f)
                            if (c = s[f]) {
                                for (var h, p = t.call(c, c.__data__, f, s), d = O(c, e), v = 0, g = p.length; v < g; ++v)(h = p[v]) && A(h, n, e, v, p, d);
                                a.push(p), o.push(c)
                            }
                    return new bt(a, o, n, e)
                },
                selectChild: Mt.selectChild,
                selectChildren: Mt.selectChildren,
                filter: function(t) {
                    "function" !== typeof t && (t = Object(ct.b)(t));
                    for (var n = this._groups, e = n.length, r = new Array(e), i = 0; i < e; ++i)
                        for (var a, o = n[i], u = o.length, c = r[i] = [], s = 0; s < u; ++s)(a = o[s]) && t.call(a, a.__data__, s, o) && c.push(a);
                    return new bt(r, this._parents, this._name, this._id)
                },
                merge: function(t) {
                    if (t._id !== this._id) throw new Error;
                    for (var n = this._groups, e = t._groups, r = n.length, i = e.length, a = Math.min(r, i), o = new Array(r), u = 0; u < a; ++u)
                        for (var c, s = n[u], l = e[u], f = s.length, h = o[u] = new Array(f), p = 0; p < f; ++p)(c = s[p] || l[p]) && (h[p] = c);
                    for (; u < r; ++u) o[u] = n[u];
                    return new bt(o, this._parents, this._name, this._id)
                },
                selection: function() {
                    return new ht(this._groups, this._parents)
                },
                transition: function() {
                    for (var t = this._name, n = this._id, e = xt(), r = this._groups, i = r.length, a = 0; a < i; ++a)
                        for (var o, u = r[a], c = u.length, s = 0; s < c; ++s)
                            if (o = u[s]) {
                                var l = O(o, n);
                                A(o, t, e, s, u, {
                                    time: l.time + l.delay + l.duration,
                                    delay: 0,
                                    duration: l.duration,
                                    ease: l.ease
                                })
                            }
                    return new bt(r, this._parents, t, e)
                },
                call: Mt.call,
                nodes: Mt.nodes,
                node: Mt.node,
                size: Mt.size,
                empty: Mt.empty,
                each: Mt.each,
                on: function(t, n) {
                    var e = this._id;
                    return arguments.length < 2 ? O(this.node(), e).on.on(t) : this.each(st(e, t, n))
                },
                attr: function(t, n) {
                    var e = Object(z.a)(t),
                        r = "transform" === e ? D : F;
                    return this.attrTween(t, "function" === typeof n ? (e.local ? Z : W)(e, r, H(this, "attr." + t, n)) : null == n ? (e.local ? J : U)(e) : (e.local ? K : G)(e, r, n))
                },
                attrTween: function(t, n) {
                    var e = "attr." + t;
                    if (arguments.length < 2) return (e = this.tween(e)) && e._value;
                    if (null == n) return this.tween(e, null);
                    if ("function" !== typeof n) throw new Error;
                    var r = Object(z.a)(t);
                    return this.tween(e, (r.local ? nt : et)(r, n))
                },
                style: function(t, n, e) {
                    var r = "transform" === (t += "") ? R : F;
                    return null == n ? this.styleTween(t, function(t, n) {
                        var e, r, i;
                        return function() {
                            var a = Object(pt.b)(this, t),
                                o = (this.style.removeProperty(t), Object(pt.b)(this, t));
                            return a === o ? null : a === e && o === r ? i : i = n(e = a, r = o)
                        }
                    }(t, r)).on("end.style." + t, dt(t)) : "function" === typeof n ? this.styleTween(t, function(t, n, e) {
                        var r, i, a;
                        return function() {
                            var o = Object(pt.b)(this, t),
                                u = e(this),
                                c = u + "";
                            return null == u && (this.style.removeProperty(t), c = u = Object(pt.b)(this, t)), o === c ? null : o === r && c === i ? a : (i = c, a = n(r = o, u))
                        }
                    }(t, r, H(this, "style." + t, n))).each(function(t, n) {
                        var e, r, i, a, o = "style." + n,
                            u = "end." + o;
                        return function() {
                            var c = j(this, t),
                                s = c.on,
                                l = null == c.value[o] ? a || (a = dt(n)) : void 0;
                            s === e && i === l || (r = (e = s).copy()).on(u, i = l), c.on = r
                        }
                    }(this._id, t)) : this.styleTween(t, function(t, n, e) {
                        var r, i, a = e + "";
                        return function() {
                            var o = Object(pt.b)(this, t);
                            return o === a ? null : o === r ? i : i = n(r = o, e)
                        }
                    }(t, r, n), e).on("end.style." + t, null)
                },
                styleTween: function(t, n, e) {
                    var r = "style." + (t += "");
                    if (arguments.length < 2) return (r = this.tween(r)) && r._value;
                    if (null == n) return this.tween(r, null);
                    if ("function" !== typeof n) throw new Error;
                    return this.tween(r, gt(t, n, null == e ? "" : e))
                },
                text: function(t) {
                    return this.tween("text", "function" === typeof t ? function(t) {
                        return function() {
                            var n = t(this);
                            this.textContent = null == n ? "" : n
                        }
                    }(H(this, "text", t)) : function(t) {
                        return function() {
                            this.textContent = t
                        }
                    }(null == t ? "" : t + ""))
                },
                textTween: function(t) {
                    var n = "text";
                    if (arguments.length < 1) return (n = this.tween(n)) && n._value;
                    if (null == t) return this.tween(n, null);
                    if ("function" !== typeof t) throw new Error;
                    return this.tween(n, mt(t))
                },
                remove: function() {
                    return this.on("end.remove", (t = this._id, function() {
                        var n = this.parentNode;
                        for (var e in this.__transition)
                            if (+e !== t) return;
                        n && n.removeChild(this)
                    }));
                    var t
                },
                tween: function(t, n) {
                    var e = this._id;
                    if (t += "", arguments.length < 2) {
                        for (var r, i = O(this.node(), e).tween, a = 0, o = i.length; a < o; ++a)
                            if ((r = i[a]).name === t) return r.value;
                        return null
                    }
                    return this.each((null == n ? I : $)(e, t, n))
                },
                delay: function(t) {
                    var n = this._id;
                    return arguments.length ? this.each(("function" === typeof t ? rt : it)(n, t)) : O(this.node(), n).delay
                },
                duration: function(t) {
                    var n = this._id;
                    return arguments.length ? this.each(("function" === typeof t ? at : ot)(n, t)) : O(this.node(), n).duration
                },
                ease: function(t) {
                    var n = this._id;
                    return arguments.length ? this.each(ut(n, t)) : O(this.node(), n).ease
                },
                easeVarying: function(t) {
                    if ("function" !== typeof t) throw new Error;
                    return this.each(function(t, n) {
                        return function() {
                            var e = n.apply(this, arguments);
                            if ("function" !== typeof e) throw new Error;
                            j(this, t).ease = e
                        }
                    }(this._id, t))
                },
                end: function() {
                    var t, n, e = this,
                        r = e._id,
                        i = e.size();
                    return new Promise((function(a, o) {
                        var u = {
                                value: o
                            },
                            c = {
                                value: function() {
                                    0 === --i && a()
                                }
                            };
                        e.each((function() {
                            var e = j(this, r),
                                i = e.on;
                            i !== t && ((n = (t = i).copy())._.cancel.push(u), n._.interrupt.push(u), n._.end.push(c)), e.on = n
                        })), 0 === i && a()
                    }))
                }
            }, Symbol.iterator, Mt[Symbol.iterator]);
            var kt = {
                time: null,
                delay: 0,
                duration: 250,
                ease: function(t) {
                    return ((t *= 2) <= 1 ? t * t * t : (t -= 2) * t * t + 2) / 2
                }
            };

            function At(t, n) {
                for (var e; !(e = t.__transition) || !(e = e[n]);)
                    if (!(t = t.parentNode)) throw new Error("transition ".concat(n, " not found"));
                return e
            }
            a.b.prototype.interrupt = function(t) {
                return this.each((function() {
                    S(this, t)
                }))
            }, a.b.prototype.transition = function(t) {
                var n, e;
                t instanceof bt ? (n = t._id, t = t._name) : (n = xt(), (e = kt).time = v(), t = null == t ? null : t + "");
                for (var r = this._groups, i = r.length, a = 0; a < i; ++a)
                    for (var o, u = r[a], c = u.length, s = 0; s < c; ++s)(o = u[s]) && A(o, t, n, s, u, e || At(o, n));
                return new bt(r, this._parents, t, n)
            }
        },
        109: function(t, n, e) {
            "use strict";
            e.d(n, "c", (function() {
                return d
            })), e.d(n, "a", (function() {
                return m
            })), e.d(n, "d", (function() {
                return w
            })), e.d(n, "b", (function() {
                return b
            }));
            var r = e(139),
                i = e(203),
                a = e(168),
                o = Object(i.a)(r.a),
                u = o.right,
                c = (o.left, Object(i.a)(a.a).center, u),
                s = e(280),
                l = e(138),
                f = e(253);

            function h(t) {
                return +t
            }
            var p = [0, 1];

            function d(t) {
                return t
            }

            function v(t, n) {
                return (n -= t = +t) ? function(e) {
                    return (e - t) / n
                } : (e = isNaN(n) ? NaN : .5, function() {
                    return e
                });
                var e
            }

            function g(t, n, e) {
                var r = t[0],
                    i = t[1],
                    a = n[0],
                    o = n[1];
                return i < r ? (r = v(i, r), a = e(o, a)) : (r = v(r, i), a = e(a, o)),
                    function(t) {
                        return a(r(t))
                    }
            }

            function y(t, n, e) {
                var r = Math.min(t.length, n.length) - 1,
                    i = new Array(r),
                    a = new Array(r),
                    o = -1;
                for (t[r] < t[0] && (t = t.slice().reverse(), n = n.slice().reverse()); ++o < r;) i[o] = v(t[o], t[o + 1]), a[o] = e(n[o], n[o + 1]);
                return function(n) {
                    var e = c(t, n, 1, r) - 1;
                    return a[e](i[e](n))
                }
            }

            function m(t, n) {
                return n.domain(t.domain()).range(t.range()).interpolate(t.interpolate()).clamp(t.clamp()).unknown(t.unknown())
            }

            function w() {
                var t, n, e, r, i, a, o = p,
                    u = p,
                    c = s.a,
                    v = d;

                function m() {
                    var t = Math.min(o.length, u.length);
                    return v !== d && (v = function(t, n) {
                        var e;
                        return t > n && (e = t, t = n, n = e),
                            function(e) {
                                return Math.max(t, Math.min(n, e))
                            }
                    }(o[0], o[t - 1])), r = t > 2 ? y : g, i = a = null, w
                }

                function w(n) {
                    return null == n || isNaN(n = +n) ? e : (i || (i = r(o.map(t), u, c)))(t(v(n)))
                }
                return w.invert = function(e) {
                        return v(n((a || (a = r(u, o.map(t), l.a)))(e)))
                    }, w.domain = function(t) {
                        return arguments.length ? (o = Array.from(t, h), m()) : o.slice()
                    }, w.range = function(t) {
                        return arguments.length ? (u = Array.from(t), m()) : u.slice()
                    }, w.rangeRound = function(t) {
                        return u = Array.from(t), c = f.a, m()
                    }, w.clamp = function(t) {
                        return arguments.length ? (v = !!t || d, m()) : v !== d
                    }, w.interpolate = function(t) {
                        return arguments.length ? (c = t, m()) : c
                    }, w.unknown = function(t) {
                        return arguments.length ? (e = t, w) : e
                    },
                    function(e, r) {
                        return t = e, n = r, m()
                    }
            }

            function b() {
                return w()(d, d)
            }
        },
        123: function(t, n, e) {
            "use strict";
            var r = e(124);
            n.a = function(t) {
                return (t = Object(r.b)(Math.abs(t))) ? t[1] : NaN
            }
        },
        124: function(t, n, e) {
            "use strict";

            function r(t, n) {
                if ((e = (t = n ? t.toExponential(n - 1) : t.toExponential()).indexOf("e")) < 0) return null;
                var e, r = t.slice(0, e);
                return [r.length > 1 ? r[0] + r.slice(2) : r, +t.slice(e + 1)]
            }
            e.d(n, "b", (function() {
                return r
            })), n.a = function(t) {
                return Math.abs(t = Math.round(t)) >= 1e21 ? t.toLocaleString("en").replace(/,/g, "") : t.toString(10)
            }
        },
        137: function(t, n, e) {
            "use strict";

            function r(t) {
                return function(n) {
                    return n.matches(t)
                }
            }
            e.d(n, "a", (function() {
                return r
            })), n.b = function(t) {
                return function() {
                    return this.matches(t)
                }
            }
        },
        138: function(t, n, e) {
            "use strict";
            n.a = function(t, n) {
                return t = +t, n = +n,
                    function(e) {
                        return t * (1 - e) + n * e
                    }
            }
        },
        139: function(t, n, e) {
            "use strict";
            n.a = function(t, n) {
                return null == t || null == n ? NaN : t < n ? -1 : t > n ? 1 : t >= n ? 0 : NaN
            }
        },
        143: function(t, n, e) {
            "use strict";
            e.d(n, "b", (function() {
                return l
            })), e.d(n, "a", (function() {
                return f
            }));
            var r = e(254),
                i = e(109),
                a = e(49),
                o = e(204),
                u = e(123),
                c = e(276);

            function s(t, n, e, i) {
                var a, s = Object(r.c)(t, n, e);
                switch ((i = Object(o.a)(null == i ? ",f" : i)).type) {
                    case "s":
                        var l = Math.max(Math.abs(t), Math.abs(n));
                        return null != i.precision || isNaN(a = function(t, n) {
                            return Math.max(0, 3 * Math.max(-8, Math.min(8, Math.floor(Object(u.a)(n) / 3))) - Object(u.a)(Math.abs(t)))
                        }(s, l)) || (i.precision = a), Object(c.b)(i, l);
                    case "":
                    case "e":
                    case "g":
                    case "p":
                    case "r":
                        null != i.precision || isNaN(a = function(t, n) {
                            return t = Math.abs(t), n = Math.abs(n) - t, Math.max(0, Object(u.a)(n) - Object(u.a)(t)) + 1
                        }(s, Math.max(Math.abs(t), Math.abs(n)))) || (i.precision = a - ("e" === i.type));
                        break;
                    case "f":
                    case "%":
                        null != i.precision || isNaN(a = function(t) {
                            return Math.max(0, -Object(u.a)(Math.abs(t)))
                        }(s)) || (i.precision = a - 2 * ("%" === i.type))
                }
                return Object(c.a)(i)
            }

            function l(t) {
                var n = t.domain;
                return t.ticks = function(t) {
                    var e = n();
                    return Object(r.a)(e[0], e[e.length - 1], null == t ? 10 : t)
                }, t.tickFormat = function(t, e) {
                    var r = n();
                    return s(r[0], r[r.length - 1], null == t ? 10 : t, e)
                }, t.nice = function(e) {
                    null == e && (e = 10);
                    var i, a, o = n(),
                        u = 0,
                        c = o.length - 1,
                        s = o[u],
                        l = o[c],
                        f = 10;
                    for (l < s && (a = s, s = l, l = a, a = u, u = c, c = a); f-- > 0;) {
                        if ((a = Object(r.b)(s, l, e)) === i) return o[u] = s, o[c] = l, n(o);
                        if (a > 0) s = Math.floor(s / a) * a, l = Math.ceil(l / a) * a;
                        else {
                            if (!(a < 0)) break;
                            s = Math.ceil(s * a) / a, l = Math.floor(l * a) / a
                        }
                        i = a
                    }
                    return t
                }, t
            }

            function f() {
                var t = Object(i.b)();
                return t.copy = function() {
                    return Object(i.a)(t, f())
                }, a.b.apply(t, arguments), l(t)
            }
        },
        163: function(t, n, e) {
            "use strict";

            function r() {}
            n.a = function(t) {
                return null == t ? r : function() {
                    return this.querySelector(t)
                }
            }
        },
        164: function(t, n, e) {
            "use strict";
            var r = e(165);
            n.a = function(t) {
                var n = t += "",
                    e = n.indexOf(":");
                return e >= 0 && "xmlns" !== (n = t.slice(0, e)) && (t = t.slice(e + 1)), r.a.hasOwnProperty(n) ? {
                    space: r.a[n],
                    local: t
                } : t
            }
        },
        165: function(t, n, e) {
            "use strict";
            e.d(n, "b", (function() {
                return r
            }));
            var r = "http://www.w3.org/1999/xhtml";
            n.a = {
                svg: "http://www.w3.org/2000/svg",
                xhtml: r,
                xlink: "http://www.w3.org/1999/xlink",
                xml: "http://www.w3.org/XML/1998/namespace",
                xmlns: "http://www.w3.org/2000/xmlns/"
            }
        },
        166: function(t, n, e) {
            "use strict";
            n.a = function(t) {
                return t.ownerDocument && t.ownerDocument.defaultView || t.document && t || t.defaultView
            }
        },
        167: function(t, n, e) {
            "use strict";
            n.a = function(t) {
                return function() {
                    return t
                }
            }
        },
        168: function(t, n, e) {
            "use strict";
            e.d(n, "b", (function() {
                return u
            }));
            var r = e(112),
                i = e.n(r),
                a = e(25),
                o = i.a.mark(u);

            function u(t, n) {
                var e, r, u, c, s, l, f;
                return i.a.wrap((function(i) {
                    for (;;) switch (i.prev = i.next) {
                        case 0:
                            if (void 0 !== n) {
                                i.next = 21;
                                break
                            }
                            e = Object(a.a)(t), i.prev = 2, e.s();
                        case 4:
                            if ((r = e.n()).done) {
                                i.next = 11;
                                break
                            }
                            if (!(null != (u = r.value) && (u = +u) >= u)) {
                                i.next = 9;
                                break
                            }
                            return i.next = 9, u;
                        case 9:
                            i.next = 4;
                            break;
                        case 11:
                            i.next = 16;
                            break;
                        case 13:
                            i.prev = 13, i.t0 = i.catch(2), e.e(i.t0);
                        case 16:
                            return i.prev = 16, e.f(), i.finish(16);
                        case 19:
                            i.next = 40;
                            break;
                        case 21:
                            c = -1, s = Object(a.a)(t), i.prev = 23, s.s();
                        case 25:
                            if ((l = s.n()).done) {
                                i.next = 32;
                                break
                            }
                            if (f = l.value, !(null != (f = n(f, ++c, t)) && (f = +f) >= f)) {
                                i.next = 30;
                                break
                            }
                            return i.next = 30, f;
                        case 30:
                            i.next = 25;
                            break;
                        case 32:
                            i.next = 37;
                            break;
                        case 34:
                            i.prev = 34, i.t1 = i.catch(23), s.e(i.t1);
                        case 37:
                            return i.prev = 37, s.f(), i.finish(37);
                        case 40:
                        case "end":
                            return i.stop()
                    }
                }), o, null, [
                    [2, 13, 16, 19],
                    [23, 34, 37, 40]
                ])
            }
            n.a = function(t) {
                return null === t ? NaN : +t
            }
        },
        200: function(t, n, e) {
            "use strict";

            function r() {
                return []
            }
            n.a = function(t) {
                return null == t ? r : function() {
                    return this.querySelectorAll(t)
                }
            }
        },
        201: function(t, n, e) {
            "use strict";
            e.d(n, "b", (function() {
                return u
            }));
            var r = e(166);

            function i(t) {
                return function() {
                    this.style.removeProperty(t)
                }
            }

            function a(t, n, e) {
                return function() {
                    this.style.setProperty(t, n, e)
                }
            }

            function o(t, n, e) {
                return function() {
                    var r = n.apply(this, arguments);
                    null == r ? this.style.removeProperty(t) : this.style.setProperty(t, r, e)
                }
            }

            function u(t, n) {
                return t.style.getPropertyValue(n) || Object(r.a)(t).getComputedStyle(t, null).getPropertyValue(n)
            }
            n.a = function(t, n, e) {
                return arguments.length > 1 ? this.each((null == n ? i : "function" === typeof n ? o : a)(t, n, null == e ? "" : e)) : u(this.node(), t)
            }
        },
        202: function(t, n, e) {
            "use strict";
            var r = e(138),
                i = /[-+]?(?:\d+\.?\d*|\.?\d+)(?:[eE][-+]?\d+)?/g,
                a = new RegExp(i.source, "g");
            n.a = function(t, n) {
                var e, o, u, c = i.lastIndex = a.lastIndex = 0,
                    s = -1,
                    l = [],
                    f = [];
                for (t += "", n += "";
                    (e = i.exec(t)) && (o = a.exec(n));)(u = o.index) > c && (u = n.slice(c, u), l[s] ? l[s] += u : l[++s] = u), (e = e[0]) === (o = o[0]) ? l[s] ? l[s] += o : l[++s] = o : (l[++s] = null, f.push({
                    i: s,
                    x: Object(r.a)(e, o)
                })), c = a.lastIndex;
                return c < n.length && (u = n.slice(c), l[s] ? l[s] += u : l[++s] = u), l.length < 2 ? f[0] ? function(t) {
                    return function(n) {
                        return t(n) + ""
                    }
                }(f[0].x) : function(t) {
                    return function() {
                        return t
                    }
                }(n) : (n = f.length, function(t) {
                    for (var e, r = 0; r < n; ++r) l[(e = f[r]).i] = e.x(t);
                    return l.join("")
                })
            }
        },
        203: function(t, n, e) {
            "use strict";
            var r = e(139);
            n.a = function(t) {
                var n = t,
                    e = t;

                function i(t, n, r, i) {
                    for (null == r && (r = 0), null == i && (i = t.length); r < i;) {
                        var a = r + i >>> 1;
                        e(t[a], n) < 0 ? r = a + 1 : i = a
                    }
                    return r
                }
                return 1 === t.length && (n = function(n, e) {
                    return t(n) - e
                }, e = function(t) {
                    return function(n, e) {
                        return Object(r.a)(t(n), e)
                    }
                }(t)), {
                    left: i,
                    center: function(t, e, r, a) {
                        null == r && (r = 0), null == a && (a = t.length);
                        var o = i(t, e, r, a - 1);
                        return o > r && n(t[o - 1], e) > -n(t[o], e) ? o - 1 : o
                    },
                    right: function(t, n, r, i) {
                        for (null == r && (r = 0), null == i && (i = t.length); r < i;) {
                            var a = r + i >>> 1;
                            e(t[a], n) > 0 ? i = a : r = a + 1
                        }
                        return r
                    }
                }
            }
        },
        204: function(t, n, e) {
            "use strict";
            e.d(n, "a", (function() {
                return i
            }));
            var r = /^(?:(.)?([<>=^]))?([+\-( ])?([$#])?(0)?(\d+)?(,)?(\.\d+)?(~)?([a-z%])?$/i;

            function i(t) {
                if (!(n = r.exec(t))) throw new Error("invalid format: " + t);
                var n;
                return new a({
                    fill: n[1],
                    align: n[2],
                    sign: n[3],
                    symbol: n[4],
                    zero: n[5],
                    width: n[6],
                    comma: n[7],
                    precision: n[8] && n[8].slice(1),
                    trim: n[9],
                    type: n[10]
                })
            }

            function a(t) {
                this.fill = void 0 === t.fill ? " " : t.fill + "", this.align = void 0 === t.align ? ">" : t.align + "", this.sign = void 0 === t.sign ? "-" : t.sign + "", this.symbol = void 0 === t.symbol ? "" : t.symbol + "", this.zero = !!t.zero, this.width = void 0 === t.width ? void 0 : +t.width, this.comma = !!t.comma, this.precision = void 0 === t.precision ? void 0 : +t.precision, this.trim = !!t.trim, this.type = void 0 === t.type ? "" : t.type + ""
            }
            i.prototype = a.prototype, a.prototype.toString = function() {
                return this.fill + this.align + this.sign + this.symbol + (this.zero ? "0" : "") + (void 0 === this.width ? "" : Math.max(1, 0 | this.width)) + (this.comma ? "," : "") + (void 0 === this.precision ? "" : "." + Math.max(0, 0 | this.precision)) + (this.trim ? "~" : "") + this.type
            }
        },
        223: function(t, n, e) {
            "use strict";
            e.d(n, "c", (function() {
                return pt
            })), e.d(n, "a", (function() {
                return dt
            }));
            var r = e(50),
                i = e(163);

            function a(t) {
                return null == t ? [] : Array.isArray(t) ? t : Array.from(t)
            }
            var o = e(200);
            var u = e(137),
                c = Array.prototype.find;

            function s() {
                return this.firstElementChild
            }
            var l = Array.prototype.filter;

            function f() {
                return Array.from(this.children)
            }
            var h = function(t) {
                return new Array(t.length)
            };

            function p(t, n) {
                this.ownerDocument = t.ownerDocument, this.namespaceURI = t.namespaceURI, this._next = null, this._parent = t, this.__data__ = n
            }
            p.prototype = {
                constructor: p,
                appendChild: function(t) {
                    return this._parent.insertBefore(t, this._next)
                },
                insertBefore: function(t, n) {
                    return this._parent.insertBefore(t, n)
                },
                querySelector: function(t) {
                    return this._parent.querySelector(t)
                },
                querySelectorAll: function(t) {
                    return this._parent.querySelectorAll(t)
                }
            };
            var d = function(t) {
                return function() {
                    return t
                }
            };

            function v(t, n, e, r, i, a) {
                for (var o, u = 0, c = n.length, s = a.length; u < s; ++u)(o = n[u]) ? (o.__data__ = a[u], r[u] = o) : e[u] = new p(t, a[u]);
                for (; u < c; ++u)(o = n[u]) && (i[u] = o)
            }

            function g(t, n, e, r, i, a, o) {
                var u, c, s, l = new Map,
                    f = n.length,
                    h = a.length,
                    d = new Array(f);
                for (u = 0; u < f; ++u)(c = n[u]) && (d[u] = s = o.call(c, c.__data__, u, n) + "", l.has(s) ? i[u] = c : l.set(s, c));
                for (u = 0; u < h; ++u) s = o.call(t, a[u], u, a) + "", (c = l.get(s)) ? (r[u] = c, c.__data__ = a[u], l.delete(s)) : e[u] = new p(t, a[u]);
                for (u = 0; u < f; ++u)(c = n[u]) && l.get(d[u]) === c && (i[u] = c)
            }

            function y(t) {
                return t.__data__
            }

            function m(t) {
                return "object" === typeof t && "length" in t ? t : Array.from(t)
            }

            function w(t, n) {
                return t < n ? -1 : t > n ? 1 : t >= n ? 0 : NaN
            }
            var b = e(25),
                _ = e(164);

            function x(t) {
                return function() {
                    this.removeAttribute(t)
                }
            }

            function M(t) {
                return function() {
                    this.removeAttributeNS(t.space, t.local)
                }
            }

            function k(t, n) {
                return function() {
                    this.setAttribute(t, n)
                }
            }

            function A(t, n) {
                return function() {
                    this.setAttributeNS(t.space, t.local, n)
                }
            }

            function N(t, n) {
                return function() {
                    var e = n.apply(this, arguments);
                    null == e ? this.removeAttribute(t) : this.setAttribute(t, e)
                }
            }

            function j(t, n) {
                return function() {
                    var e = n.apply(this, arguments);
                    null == e ? this.removeAttributeNS(t.space, t.local) : this.setAttributeNS(t.space, t.local, e)
                }
            }
            var O = e(201);

            function E(t) {
                return function() {
                    delete this[t]
                }
            }

            function S(t, n) {
                return function() {
                    this[t] = n
                }
            }

            function C(t, n) {
                return function() {
                    var e = n.apply(this, arguments);
                    null == e ? delete this[t] : this[t] = e
                }
            }

            function q(t) {
                return t.trim().split(/^|\s+/)
            }

            function P(t) {
                return t.classList || new T(t)
            }

            function T(t) {
                this._node = t, this._names = q(t.getAttribute("class") || "")
            }

            function X(t, n) {
                for (var e = P(t), r = -1, i = n.length; ++r < i;) e.add(n[r])
            }

            function L(t, n) {
                for (var e = P(t), r = -1, i = n.length; ++r < i;) e.remove(n[r])
            }

            function R(t) {
                return function() {
                    X(this, t)
                }
            }

            function D(t) {
                return function() {
                    L(this, t)
                }
            }

            function z(t, n) {
                return function() {
                    (n.apply(this, arguments) ? X : L)(this, t)
                }
            }
            T.prototype = {
                add: function(t) {
                    this._names.indexOf(t) < 0 && (this._names.push(t), this._node.setAttribute("class", this._names.join(" ")))
                },
                remove: function(t) {
                    var n = this._names.indexOf(t);
                    n >= 0 && (this._names.splice(n, 1), this._node.setAttribute("class", this._names.join(" ")))
                },
                contains: function(t) {
                    return this._names.indexOf(t) >= 0
                }
            };

            function I() {
                this.textContent = ""
            }

            function $(t) {
                return function() {
                    this.textContent = t
                }
            }

            function H(t) {
                return function() {
                    var n = t.apply(this, arguments);
                    this.textContent = null == n ? "" : n
                }
            }

            function B() {
                this.innerHTML = ""
            }

            function Y(t) {
                return function() {
                    this.innerHTML = t
                }
            }

            function V(t) {
                return function() {
                    var n = t.apply(this, arguments);
                    this.innerHTML = null == n ? "" : n
                }
            }

            function F() {
                this.nextSibling && this.parentNode.appendChild(this)
            }

            function U() {
                this.previousSibling && this.parentNode.insertBefore(this, this.parentNode.firstChild)
            }
            var J = e(165);

            function G(t) {
                return function() {
                    var n = this.ownerDocument,
                        e = this.namespaceURI;
                    return e === J.b && n.documentElement.namespaceURI === J.b ? n.createElement(t) : n.createElementNS(e, t)
                }
            }

            function K(t) {
                return function() {
                    return this.ownerDocument.createElementNS(t.space, t.local)
                }
            }
            var W = function(t) {
                var n = Object(_.a)(t);
                return (n.local ? K : G)(n)
            };

            function Z() {
                return null
            }

            function Q() {
                var t = this.parentNode;
                t && t.removeChild(this)
            }

            function tt() {
                var t = this.cloneNode(!1),
                    n = this.parentNode;
                return n ? n.insertBefore(t, this.nextSibling) : t
            }

            function nt() {
                var t = this.cloneNode(!0),
                    n = this.parentNode;
                return n ? n.insertBefore(t, this.nextSibling) : t
            }

            function et(t) {
                return t.trim().split(/^|\s+/).map((function(t) {
                    var n = "",
                        e = t.indexOf(".");
                    return e >= 0 && (n = t.slice(e + 1), t = t.slice(0, e)), {
                        type: t,
                        name: n
                    }
                }))
            }

            function rt(t) {
                return function() {
                    var n = this.__on;
                    if (n) {
                        for (var e, r = 0, i = -1, a = n.length; r < a; ++r) e = n[r], t.type && e.type !== t.type || e.name !== t.name ? n[++i] = e : this.removeEventListener(e.type, e.listener, e.options);
                        ++i ? n.length = i : delete this.__on
                    }
                }
            }

            function it(t, n, e) {
                return function() {
                    var r, i = this.__on,
                        a = function(t) {
                            return function(n) {
                                t.call(this, n, this.__data__)
                            }
                        }(n);
                    if (i)
                        for (var o = 0, u = i.length; o < u; ++o)
                            if ((r = i[o]).type === t.type && r.name === t.name) return this.removeEventListener(r.type, r.listener, r.options), this.addEventListener(r.type, r.listener = a, r.options = e), void(r.value = n);
                    this.addEventListener(t.type, a, e), r = {
                        type: t.type,
                        name: t.name,
                        value: n,
                        listener: a,
                        options: e
                    }, i ? i.push(r) : this.__on = [r]
                }
            }
            var at = e(166);

            function ot(t, n, e) {
                var r = Object(at.a)(t),
                    i = r.CustomEvent;
                "function" === typeof i ? i = new i(n, e) : (i = r.document.createEvent("Event"), e ? (i.initEvent(n, e.bubbles, e.cancelable), i.detail = e.detail) : i.initEvent(n, !1, !1)), t.dispatchEvent(i)
            }

            function ut(t, n) {
                return function() {
                    return ot(this, t, n)
                }
            }

            function ct(t, n) {
                return function() {
                    return ot(this, t, n.apply(this, arguments))
                }
            }
            var st = e(112),
                lt = e.n(st),
                ft = lt.a.mark(ht);

            function ht() {
                var t, n, e, r, i, a, o;
                return lt.a.wrap((function(u) {
                    for (;;) switch (u.prev = u.next) {
                        case 0:
                            t = this._groups, n = 0, e = t.length;
                        case 1:
                            if (!(n < e)) {
                                u.next = 13;
                                break
                            }
                            r = t[n], i = 0, a = r.length;
                        case 3:
                            if (!(i < a)) {
                                u.next = 10;
                                break
                            }
                            if (!(o = r[i])) {
                                u.next = 7;
                                break
                            }
                            return u.next = 7, o;
                        case 7:
                            ++i, u.next = 3;
                            break;
                        case 10:
                            ++n, u.next = 1;
                            break;
                        case 13:
                        case "end":
                            return u.stop()
                    }
                }), ft, this)
            }
            var pt = [null];

            function dt(t, n) {
                this._groups = t, this._parents = n
            }

            function vt() {
                return new dt([
                    [document.documentElement]
                ], pt)
            }
            dt.prototype = vt.prototype = Object(r.a)({
                constructor: dt,
                select: function(t) {
                    "function" !== typeof t && (t = Object(i.a)(t));
                    for (var n = this._groups, e = n.length, r = new Array(e), a = 0; a < e; ++a)
                        for (var o, u, c = n[a], s = c.length, l = r[a] = new Array(s), f = 0; f < s; ++f)(o = c[f]) && (u = t.call(o, o.__data__, f, c)) && ("__data__" in o && (u.__data__ = o.__data__), l[f] = u);
                    return new dt(r, this._parents)
                },
                selectAll: function(t) {
                    t = "function" === typeof t ? function(t) {
                        return function() {
                            return a(t.apply(this, arguments))
                        }
                    }(t) : Object(o.a)(t);
                    for (var n = this._groups, e = n.length, r = [], i = [], u = 0; u < e; ++u)
                        for (var c, s = n[u], l = s.length, f = 0; f < l; ++f)(c = s[f]) && (r.push(t.call(c, c.__data__, f, s)), i.push(c));
                    return new dt(r, i)
                },
                selectChild: function(t) {
                    return this.select(null == t ? s : function(t) {
                        return function() {
                            return c.call(this.children, t)
                        }
                    }("function" === typeof t ? t : Object(u.a)(t)))
                },
                selectChildren: function(t) {
                    return this.selectAll(null == t ? f : function(t) {
                        return function() {
                            return l.call(this.children, t)
                        }
                    }("function" === typeof t ? t : Object(u.a)(t)))
                },
                filter: function(t) {
                    "function" !== typeof t && (t = Object(u.b)(t));
                    for (var n = this._groups, e = n.length, r = new Array(e), i = 0; i < e; ++i)
                        for (var a, o = n[i], c = o.length, s = r[i] = [], l = 0; l < c; ++l)(a = o[l]) && t.call(a, a.__data__, l, o) && s.push(a);
                    return new dt(r, this._parents)
                },
                data: function(t, n) {
                    if (!arguments.length) return Array.from(this, y);
                    var e = n ? g : v,
                        r = this._parents,
                        i = this._groups;
                    "function" !== typeof t && (t = d(t));
                    for (var a = i.length, o = new Array(a), u = new Array(a), c = new Array(a), s = 0; s < a; ++s) {
                        var l = r[s],
                            f = i[s],
                            h = f.length,
                            p = m(t.call(l, l && l.__data__, s, r)),
                            w = p.length,
                            b = u[s] = new Array(w),
                            _ = o[s] = new Array(w),
                            x = c[s] = new Array(h);
                        e(l, f, b, _, x, p, n);
                        for (var M, k, A = 0, N = 0; A < w; ++A)
                            if (M = b[A]) {
                                for (A >= N && (N = A + 1); !(k = _[N]) && ++N < w;);
                                M._next = k || null
                            }
                    }
                    return (o = new dt(o, r))._enter = u, o._exit = c, o
                },
                enter: function() {
                    return new dt(this._enter || this._groups.map(h), this._parents)
                },
                exit: function() {
                    return new dt(this._exit || this._groups.map(h), this._parents)
                },
                join: function(t, n, e) {
                    var r = this.enter(),
                        i = this,
                        a = this.exit();
                    return "function" === typeof t ? (r = t(r)) && (r = r.selection()) : r = r.append(t + ""), null != n && (i = n(i)) && (i = i.selection()), null == e ? a.remove() : e(a), r && i ? r.merge(i).order() : i
                },
                merge: function(t) {
                    for (var n = t.selection ? t.selection() : t, e = this._groups, r = n._groups, i = e.length, a = r.length, o = Math.min(i, a), u = new Array(i), c = 0; c < o; ++c)
                        for (var s, l = e[c], f = r[c], h = l.length, p = u[c] = new Array(h), d = 0; d < h; ++d)(s = l[d] || f[d]) && (p[d] = s);
                    for (; c < i; ++c) u[c] = e[c];
                    return new dt(u, this._parents)
                },
                selection: function() {
                    return this
                },
                order: function() {
                    for (var t = this._groups, n = -1, e = t.length; ++n < e;)
                        for (var r, i = t[n], a = i.length - 1, o = i[a]; --a >= 0;)(r = i[a]) && (o && 4 ^ r.compareDocumentPosition(o) && o.parentNode.insertBefore(r, o), o = r);
                    return this
                },
                sort: function(t) {
                    function n(n, e) {
                        return n && e ? t(n.__data__, e.__data__) : !n - !e
                    }
                    t || (t = w);
                    for (var e = this._groups, r = e.length, i = new Array(r), a = 0; a < r; ++a) {
                        for (var o, u = e[a], c = u.length, s = i[a] = new Array(c), l = 0; l < c; ++l)(o = u[l]) && (s[l] = o);
                        s.sort(n)
                    }
                    return new dt(i, this._parents).order()
                },
                call: function() {
                    var t = arguments[0];
                    return arguments[0] = this, t.apply(null, arguments), this
                },
                nodes: function() {
                    return Array.from(this)
                },
                node: function() {
                    for (var t = this._groups, n = 0, e = t.length; n < e; ++n)
                        for (var r = t[n], i = 0, a = r.length; i < a; ++i) {
                            var o = r[i];
                            if (o) return o
                        }
                    return null
                },
                size: function() {
                    var t, n = 0,
                        e = Object(b.a)(this);
                    try {
                        for (e.s(); !(t = e.n()).done;) {
                            t.value;
                            ++n
                        }
                    } catch (r) {
                        e.e(r)
                    } finally {
                        e.f()
                    }
                    return n
                },
                empty: function() {
                    return !this.node()
                },
                each: function(t) {
                    for (var n = this._groups, e = 0, r = n.length; e < r; ++e)
                        for (var i, a = n[e], o = 0, u = a.length; o < u; ++o)(i = a[o]) && t.call(i, i.__data__, o, a);
                    return this
                },
                attr: function(t, n) {
                    var e = Object(_.a)(t);
                    if (arguments.length < 2) {
                        var r = this.node();
                        return e.local ? r.getAttributeNS(e.space, e.local) : r.getAttribute(e)
                    }
                    return this.each((null == n ? e.local ? M : x : "function" === typeof n ? e.local ? j : N : e.local ? A : k)(e, n))
                },
                style: O.a,
                property: function(t, n) {
                    return arguments.length > 1 ? this.each((null == n ? E : "function" === typeof n ? C : S)(t, n)) : this.node()[t]
                },
                classed: function(t, n) {
                    var e = q(t + "");
                    if (arguments.length < 2) {
                        for (var r = P(this.node()), i = -1, a = e.length; ++i < a;)
                            if (!r.contains(e[i])) return !1;
                        return !0
                    }
                    return this.each(("function" === typeof n ? z : n ? R : D)(e, n))
                },
                text: function(t) {
                    return arguments.length ? this.each(null == t ? I : ("function" === typeof t ? H : $)(t)) : this.node().textContent
                },
                html: function(t) {
                    return arguments.length ? this.each(null == t ? B : ("function" === typeof t ? V : Y)(t)) : this.node().innerHTML
                },
                raise: function() {
                    return this.each(F)
                },
                lower: function() {
                    return this.each(U)
                },
                append: function(t) {
                    var n = "function" === typeof t ? t : W(t);
                    return this.select((function() {
                        return this.appendChild(n.apply(this, arguments))
                    }))
                },
                insert: function(t, n) {
                    var e = "function" === typeof t ? t : W(t),
                        r = null == n ? Z : "function" === typeof n ? n : Object(i.a)(n);
                    return this.select((function() {
                        return this.insertBefore(e.apply(this, arguments), r.apply(this, arguments) || null)
                    }))
                },
                remove: function() {
                    return this.each(Q)
                },
                clone: function(t) {
                    return this.select(t ? nt : tt)
                },
                datum: function(t) {
                    return arguments.length ? this.property("__data__", t) : this.node().__data__
                },
                on: function(t, n, e) {
                    var r, i, a = et(t + ""),
                        o = a.length;
                    if (!(arguments.length < 2)) {
                        for (u = n ? it : rt, r = 0; r < o; ++r) this.each(u(a[r], n, e));
                        return this
                    }
                    var u = this.node().__on;
                    if (u)
                        for (var c, s = 0, l = u.length; s < l; ++s)
                            for (r = 0, c = u[s]; r < o; ++r)
                                if ((i = a[r]).type === c.type && i.name === c.name) return c.value
                },
                dispatch: function(t, n) {
                    return this.each(("function" === typeof n ? ct : ut)(t, n))
                }
            }, Symbol.iterator, ht);
            n.b = vt
        },
        227: function(t, n, e) {
            "use strict";
            e.d(n, "b", (function() {
                return l
            }));
            var r = e(296);

            function i(t, n, e, r, i) {
                var a = t * t,
                    o = a * t;
                return ((1 - 3 * t + 3 * a - o) * n + (4 - 6 * a + 3 * o) * e + (1 + 3 * t + 3 * a - 3 * o) * r + o * i) / 6
            }
            var a = e(167);

            function o(t, n) {
                return function(e) {
                    return t + e * n
                }
            }

            function u(t) {
                return 1 === (t = +t) ? c : function(n, e) {
                    return e - n ? function(t, n, e) {
                        return t = Math.pow(t, e), n = Math.pow(n, e) - t, e = 1 / e,
                            function(r) {
                                return Math.pow(t + r * n, e)
                            }
                    }(n, e, t) : Object(a.a)(isNaN(n) ? e : n)
                }
            }

            function c(t, n) {
                var e = n - t;
                return e ? o(t, e) : Object(a.a)(isNaN(t) ? n : t)
            }
            n.a = function t(n) {
                var e = u(n);

                function i(t, n) {
                    var i = e((t = Object(r.b)(t)).r, (n = Object(r.b)(n)).r),
                        a = e(t.g, n.g),
                        o = e(t.b, n.b),
                        u = c(t.opacity, n.opacity);
                    return function(n) {
                        return t.r = i(n), t.g = a(n), t.b = o(n), t.opacity = u(n), t + ""
                    }
                }
                return i.gamma = t, i
            }(1);

            function s(t) {
                return function(n) {
                    var e, i, a = n.length,
                        o = new Array(a),
                        u = new Array(a),
                        c = new Array(a);
                    for (e = 0; e < a; ++e) i = Object(r.b)(n[e]), o[e] = i.r || 0, u[e] = i.g || 0, c[e] = i.b || 0;
                    return o = t(o), u = t(u), c = t(c), i.opacity = 1,
                        function(t) {
                            return i.r = o(t), i.g = u(t), i.b = c(t), i + ""
                        }
                }
            }
            var l = s((function(t) {
                var n = t.length - 1;
                return function(e) {
                    var r = e <= 0 ? e = 0 : e >= 1 ? (e = 1, n - 1) : Math.floor(e * n),
                        a = t[r],
                        o = t[r + 1],
                        u = r > 0 ? t[r - 1] : 2 * a - o,
                        c = r < n - 1 ? t[r + 2] : 2 * o - a;
                    return i((e - r / n) * n, u, a, o, c)
                }
            }));
            s((function(t) {
                var n = t.length;
                return function(e) {
                    var r = Math.floor(((e %= 1) < 0 ? ++e : e) * n),
                        a = t[(r + n - 1) % n],
                        o = t[r % n],
                        u = t[(r + 1) % n],
                        c = t[(r + 2) % n];
                    return i((e - r / n) * n, a, o, u, c)
                }
            }))
        },
        252: function(t, n, e) {
            "use strict";
            var r = {
                value: function() {}
            };

            function i() {
                for (var t, n = 0, e = arguments.length, r = {}; n < e; ++n) {
                    if (!(t = arguments[n] + "") || t in r || /[\s.]/.test(t)) throw new Error("illegal type: " + t);
                    r[t] = []
                }
                return new a(r)
            }

            function a(t) {
                this._ = t
            }

            function o(t, n) {
                return t.trim().split(/^|\s+/).map((function(t) {
                    var e = "",
                        r = t.indexOf(".");
                    if (r >= 0 && (e = t.slice(r + 1), t = t.slice(0, r)), t && !n.hasOwnProperty(t)) throw new Error("unknown type: " + t);
                    return {
                        type: t,
                        name: e
                    }
                }))
            }

            function u(t, n) {
                for (var e, r = 0, i = t.length; r < i; ++r)
                    if ((e = t[r]).name === n) return e.value
            }

            function c(t, n, e) {
                for (var i = 0, a = t.length; i < a; ++i)
                    if (t[i].name === n) {
                        t[i] = r, t = t.slice(0, i).concat(t.slice(i + 1));
                        break
                    }
                return null != e && t.push({
                    name: n,
                    value: e
                }), t
            }
            a.prototype = i.prototype = {
                constructor: a,
                on: function(t, n) {
                    var e, r = this._,
                        i = o(t + "", r),
                        a = -1,
                        s = i.length;
                    if (!(arguments.length < 2)) {
                        if (null != n && "function" !== typeof n) throw new Error("invalid callback: " + n);
                        for (; ++a < s;)
                            if (e = (t = i[a]).type) r[e] = c(r[e], t.name, n);
                            else if (null == n)
                            for (e in r) r[e] = c(r[e], t.name, null);
                        return this
                    }
                    for (; ++a < s;)
                        if ((e = (t = i[a]).type) && (e = u(r[e], t.name))) return e
                },
                copy: function() {
                    var t = {},
                        n = this._;
                    for (var e in n) t[e] = n[e].slice();
                    return new a(t)
                },
                call: function(t, n) {
                    if ((e = arguments.length - 2) > 0)
                        for (var e, r, i = new Array(e), a = 0; a < e; ++a) i[a] = arguments[a + 2];
                    if (!this._.hasOwnProperty(t)) throw new Error("unknown type: " + t);
                    for (a = 0, e = (r = this._[t]).length; a < e; ++a) r[a].value.apply(n, i)
                },
                apply: function(t, n, e) {
                    if (!this._.hasOwnProperty(t)) throw new Error("unknown type: " + t);
                    for (var r = this._[t], i = 0, a = r.length; i < a; ++i) r[i].value.apply(n, e)
                }
            }, n.a = i
        },
        253: function(t, n, e) {
            "use strict";
            n.a = function(t, n) {
                return t = +t, n = +n,
                    function(e) {
                        return Math.round(t * (1 - e) + n * e)
                    }
            }
        },
        254: function(t, n, e) {
            "use strict";
            e.d(n, "b", (function() {
                return o
            })), e.d(n, "c", (function() {
                return u
            }));
            var r = Math.sqrt(50),
                i = Math.sqrt(10),
                a = Math.sqrt(2);

            function o(t, n, e) {
                var o = (n - t) / Math.max(0, e),
                    u = Math.floor(Math.log(o) / Math.LN10),
                    c = o / Math.pow(10, u);
                return u >= 0 ? (c >= r ? 10 : c >= i ? 5 : c >= a ? 2 : 1) * Math.pow(10, u) : -Math.pow(10, -u) / (c >= r ? 10 : c >= i ? 5 : c >= a ? 2 : 1)
            }

            function u(t, n, e) {
                var o = Math.abs(n - t) / Math.max(0, e),
                    u = Math.pow(10, Math.floor(Math.log(o) / Math.LN10)),
                    c = o / u;
                return c >= r ? u *= 10 : c >= i ? u *= 5 : c >= a && (u *= 2), n < t ? -u : u
            }
            n.a = function(t, n, e) {
                var r, i, a, u, c = -1;
                if (e = +e, (t = +t) === (n = +n) && e > 0) return [t];
                if ((r = n < t) && (i = t, t = n, n = i), 0 === (u = o(t, n, e)) || !isFinite(u)) return [];
                if (u > 0) {
                    var s = Math.round(t / u),
                        l = Math.round(n / u);
                    for (s * u < t && ++s, l * u > n && --l, a = new Array(i = l - s + 1); ++c < i;) a[c] = (s + c) * u
                } else {
                    u = -u;
                    var f = Math.round(t * u),
                        h = Math.round(n * u);
                    for (f / u < t && ++f, h / u > n && --h, a = new Array(i = h - f + 1); ++c < i;) a[c] = (f + c) / u
                }
                return r && a.reverse(), a
            }
        },
        255: function(t, n, e) {
            "use strict";
            var r = e(223);
            n.a = function(t) {
                return "string" === typeof t ? new r.a([
                    [document.querySelector(t)]
                ], [document.documentElement]) : new r.a([
                    [t]
                ], r.c)
            }
        },
        276: function(t, n, e) {
            "use strict";
            e.d(n, "a", (function() {
                return a
            })), e.d(n, "b", (function() {
                return o
            }));
            var r, i, a, o, u = e(123),
                c = e(204),
                s = e(124),
                l = function(t, n) {
                    var e = Object(s.b)(t, n);
                    if (!e) return t + "";
                    var r = e[0],
                        i = e[1];
                    return i < 0 ? "0." + new Array(-i).join("0") + r : r.length > i + 1 ? r.slice(0, i + 1) + "." + r.slice(i + 1) : r + new Array(i - r.length + 2).join("0")
                },
                f = {
                    "%": function(t, n) {
                        return (100 * t).toFixed(n)
                    },
                    b: function(t) {
                        return Math.round(t).toString(2)
                    },
                    c: function(t) {
                        return t + ""
                    },
                    d: s.a,
                    e: function(t, n) {
                        return t.toExponential(n)
                    },
                    f: function(t, n) {
                        return t.toFixed(n)
                    },
                    g: function(t, n) {
                        return t.toPrecision(n)
                    },
                    o: function(t) {
                        return Math.round(t).toString(8)
                    },
                    p: function(t, n) {
                        return l(100 * t, n)
                    },
                    r: l,
                    s: function(t, n) {
                        var e = Object(s.b)(t, n);
                        if (!e) return t + "";
                        var i = e[0],
                            a = e[1],
                            o = a - (r = 3 * Math.max(-8, Math.min(8, Math.floor(a / 3)))) + 1,
                            u = i.length;
                        return o === u ? i : o > u ? i + new Array(o - u + 1).join("0") : o > 0 ? i.slice(0, o) + "." + i.slice(o) : "0." + new Array(1 - o).join("0") + Object(s.b)(t, Math.max(0, n + o - 1))[0]
                    },
                    X: function(t) {
                        return Math.round(t).toString(16).toUpperCase()
                    },
                    x: function(t) {
                        return Math.round(t).toString(16)
                    }
                },
                h = function(t) {
                    return t
                },
                p = Array.prototype.map,
                d = ["y", "z", "a", "f", "p", "n", "\xb5", "m", "", "k", "M", "G", "T", "P", "E", "Z", "Y"];
            i = function(t) {
                var n, e, i = void 0 === t.grouping || void 0 === t.thousands ? h : (n = p.call(t.grouping, Number), e = t.thousands + "", function(t, r) {
                        for (var i = t.length, a = [], o = 0, u = n[0], c = 0; i > 0 && u > 0 && (c + u + 1 > r && (u = Math.max(1, r - c)), a.push(t.substring(i -= u, i + u)), !((c += u + 1) > r));) u = n[o = (o + 1) % n.length];
                        return a.reverse().join(e)
                    }),
                    a = void 0 === t.currency ? "" : t.currency[0] + "",
                    o = void 0 === t.currency ? "" : t.currency[1] + "",
                    s = void 0 === t.decimal ? "." : t.decimal + "",
                    l = void 0 === t.numerals ? h : function(t) {
                        return function(n) {
                            return n.replace(/[0-9]/g, (function(n) {
                                return t[+n]
                            }))
                        }
                    }(p.call(t.numerals, String)),
                    v = void 0 === t.percent ? "%" : t.percent + "",
                    g = void 0 === t.minus ? "\u2212" : t.minus + "",
                    y = void 0 === t.nan ? "NaN" : t.nan + "";

                function m(t) {
                    var n = (t = Object(c.a)(t)).fill,
                        e = t.align,
                        u = t.sign,
                        h = t.symbol,
                        p = t.zero,
                        m = t.width,
                        w = t.comma,
                        b = t.precision,
                        _ = t.trim,
                        x = t.type;
                    "n" === x ? (w = !0, x = "g") : f[x] || (void 0 === b && (b = 12), _ = !0, x = "g"), (p || "0" === n && "=" === e) && (p = !0, n = "0", e = "=");
                    var M = "$" === h ? a : "#" === h && /[boxX]/.test(x) ? "0" + x.toLowerCase() : "",
                        k = "$" === h ? o : /[%p]/.test(x) ? v : "",
                        A = f[x],
                        N = /[defgprs%]/.test(x);

                    function j(t) {
                        var a, o, c, f = M,
                            h = k;
                        if ("c" === x) h = A(t) + h, t = "";
                        else {
                            var v = (t = +t) < 0 || 1 / t < 0;
                            if (t = isNaN(t) ? y : A(Math.abs(t), b), _ && (t = function(t) {
                                    t: for (var n, e = t.length, r = 1, i = -1; r < e; ++r) switch (t[r]) {
                                        case ".":
                                            i = n = r;
                                            break;
                                        case "0":
                                            0 === i && (i = r), n = r;
                                            break;
                                        default:
                                            if (!+t[r]) break t;
                                            i > 0 && (i = 0)
                                    }
                                    return i > 0 ? t.slice(0, i) + t.slice(n + 1) : t
                                }(t)), v && 0 === +t && "+" !== u && (v = !1), f = (v ? "(" === u ? u : g : "-" === u || "(" === u ? "" : u) + f, h = ("s" === x ? d[8 + r / 3] : "") + h + (v && "(" === u ? ")" : ""), N)
                                for (a = -1, o = t.length; ++a < o;)
                                    if (48 > (c = t.charCodeAt(a)) || c > 57) {
                                        h = (46 === c ? s + t.slice(a + 1) : t.slice(a)) + h, t = t.slice(0, a);
                                        break
                                    }
                        }
                        w && !p && (t = i(t, 1 / 0));
                        var j = f.length + t.length + h.length,
                            O = j < m ? new Array(m - j + 1).join(n) : "";
                        switch (w && p && (t = i(O + t, O.length ? m - h.length : 1 / 0), O = ""), e) {
                            case "<":
                                t = f + t + h + O;
                                break;
                            case "=":
                                t = f + O + t + h;
                                break;
                            case "^":
                                t = O.slice(0, j = O.length >> 1) + f + t + h + O.slice(j);
                                break;
                            default:
                                t = O + f + t + h
                        }
                        return l(t)
                    }
                    return b = void 0 === b ? 6 : /[gprs]/.test(x) ? Math.max(1, Math.min(21, b)) : Math.max(0, Math.min(20, b)), j.toString = function() {
                        return t + ""
                    }, j
                }
                return {
                    format: m,
                    formatPrefix: function(t, n) {
                        var e = m(((t = Object(c.a)(t)).type = "f", t)),
                            r = 3 * Math.max(-8, Math.min(8, Math.floor(Object(u.a)(n) / 3))),
                            i = Math.pow(10, -r),
                            a = d[8 + r / 3];
                        return function(t) {
                            return e(i * t) + a
                        }
                    }
                }
            }({
                thousands: ",",
                grouping: [3],
                currency: ["$", ""]
            }), a = i.format, o = i.formatPrefix
        },
        280: function(t, n, e) {
            "use strict";
            var r = e(296),
                i = e(227),
                a = function(t, n) {
                    n || (n = []);
                    var e, r = t ? Math.min(n.length, t.length) : 0,
                        i = n.slice();
                    return function(a) {
                        for (e = 0; e < r; ++e) i[e] = t[e] * (1 - a) + n[e] * a;
                        return i
                    }
                };

            function o(t) {
                return ArrayBuffer.isView(t) && !(t instanceof DataView)
            }

            function u(t, n) {
                var e, r = n ? n.length : 0,
                    i = t ? Math.min(r, t.length) : 0,
                    a = new Array(i),
                    o = new Array(r);
                for (e = 0; e < i; ++e) a[e] = p(t[e], n[e]);
                for (; e < r; ++e) o[e] = n[e];
                return function(t) {
                    for (e = 0; e < i; ++e) o[e] = a[e](t);
                    return o
                }
            }
            var c = function(t, n) {
                    var e = new Date;
                    return t = +t, n = +n,
                        function(r) {
                            return e.setTime(t * (1 - r) + n * r), e
                        }
                },
                s = e(138),
                l = function(t, n) {
                    var e, r = {},
                        i = {};
                    for (e in null !== t && "object" === typeof t || (t = {}), null !== n && "object" === typeof n || (n = {}), n) e in t ? r[e] = p(t[e], n[e]) : i[e] = n[e];
                    return function(t) {
                        for (e in r) i[e] = r[e](t);
                        return i
                    }
                },
                f = e(202),
                h = e(167),
                p = n.a = function(t, n) {
                    var e, p = typeof n;
                    return null == n || "boolean" === p ? Object(h.a)(n) : ("number" === p ? s.a : "string" === p ? (e = Object(r.a)(n)) ? (n = e, i.a) : f.a : n instanceof r.a ? i.a : n instanceof Date ? c : o(n) ? a : Array.isArray(n) ? u : "function" !== typeof n.valueOf && "function" !== typeof n.toString || isNaN(n) ? l : s.a)(t, n)
                }
        },
        296: function(t, n, e) {
            "use strict";
            e.d(n, "a", (function() {
                return _
            })), e.d(n, "b", (function() {
                return A
            }));
            var r = function(t, n, e) {
                t.prototype = n.prototype = e, e.constructor = t
            };

            function i(t, n) {
                var e = Object.create(t.prototype);
                for (var r in n) e[r] = n[r];
                return e
            }

            function a() {}
            var o = .7,
                u = 1 / o,
                c = "\\s*([+-]?\\d+)\\s*",
                s = "\\s*([+-]?\\d*\\.?\\d+(?:[eE][+-]?\\d+)?)\\s*",
                l = "\\s*([+-]?\\d*\\.?\\d+(?:[eE][+-]?\\d+)?)%\\s*",
                f = /^#([0-9a-f]{3,8})$/,
                h = new RegExp("^rgb\\(" + [c, c, c] + "\\)$"),
                p = new RegExp("^rgb\\(" + [l, l, l] + "\\)$"),
                d = new RegExp("^rgba\\(" + [c, c, c, s] + "\\)$"),
                v = new RegExp("^rgba\\(" + [l, l, l, s] + "\\)$"),
                g = new RegExp("^hsl\\(" + [s, l, l] + "\\)$"),
                y = new RegExp("^hsla\\(" + [s, l, l, s] + "\\)$"),
                m = {
                    aliceblue: 15792383,
                    antiquewhite: 16444375,
                    aqua: 65535,
                    aquamarine: 8388564,
                    azure: 15794175,
                    beige: 16119260,
                    bisque: 16770244,
                    black: 0,
                    blanchedalmond: 16772045,
                    blue: 255,
                    blueviolet: 9055202,
                    brown: 10824234,
                    burlywood: 14596231,
                    cadetblue: 6266528,
                    chartreuse: 8388352,
                    chocolate: 13789470,
                    coral: 16744272,
                    cornflowerblue: 6591981,
                    cornsilk: 16775388,
                    crimson: 14423100,
                    cyan: 65535,
                    darkblue: 139,
                    darkcyan: 35723,
                    darkgoldenrod: 12092939,
                    darkgray: 11119017,
                    darkgreen: 25600,
                    darkgrey: 11119017,
                    darkkhaki: 12433259,
                    darkmagenta: 9109643,
                    darkolivegreen: 5597999,
                    darkorange: 16747520,
                    darkorchid: 10040012,
                    darkred: 9109504,
                    darksalmon: 15308410,
                    darkseagreen: 9419919,
                    darkslateblue: 4734347,
                    darkslategray: 3100495,
                    darkslategrey: 3100495,
                    darkturquoise: 52945,
                    darkviolet: 9699539,
                    deeppink: 16716947,
                    deepskyblue: 49151,
                    dimgray: 6908265,
                    dimgrey: 6908265,
                    dodgerblue: 2003199,
                    firebrick: 11674146,
                    floralwhite: 16775920,
                    forestgreen: 2263842,
                    fuchsia: 16711935,
                    gainsboro: 14474460,
                    ghostwhite: 16316671,
                    gold: 16766720,
                    goldenrod: 14329120,
                    gray: 8421504,
                    green: 32768,
                    greenyellow: 11403055,
                    grey: 8421504,
                    honeydew: 15794160,
                    hotpink: 16738740,
                    indianred: 13458524,
                    indigo: 4915330,
                    ivory: 16777200,
                    khaki: 15787660,
                    lavender: 15132410,
                    lavenderblush: 16773365,
                    lawngreen: 8190976,
                    lemonchiffon: 16775885,
                    lightblue: 11393254,
                    lightcoral: 15761536,
                    lightcyan: 14745599,
                    lightgoldenrodyellow: 16448210,
                    lightgray: 13882323,
                    lightgreen: 9498256,
                    lightgrey: 13882323,
                    lightpink: 16758465,
                    lightsalmon: 16752762,
                    lightseagreen: 2142890,
                    lightskyblue: 8900346,
                    lightslategray: 7833753,
                    lightslategrey: 7833753,
                    lightsteelblue: 11584734,
                    lightyellow: 16777184,
                    lime: 65280,
                    limegreen: 3329330,
                    linen: 16445670,
                    magenta: 16711935,
                    maroon: 8388608,
                    mediumaquamarine: 6737322,
                    mediumblue: 205,
                    mediumorchid: 12211667,
                    mediumpurple: 9662683,
                    mediumseagreen: 3978097,
                    mediumslateblue: 8087790,
                    mediumspringgreen: 64154,
                    mediumturquoise: 4772300,
                    mediumvioletred: 13047173,
                    midnightblue: 1644912,
                    mintcream: 16121850,
                    mistyrose: 16770273,
                    moccasin: 16770229,
                    navajowhite: 16768685,
                    navy: 128,
                    oldlace: 16643558,
                    olive: 8421376,
                    olivedrab: 7048739,
                    orange: 16753920,
                    orangered: 16729344,
                    orchid: 14315734,
                    palegoldenrod: 15657130,
                    palegreen: 10025880,
                    paleturquoise: 11529966,
                    palevioletred: 14381203,
                    papayawhip: 16773077,
                    peachpuff: 16767673,
                    peru: 13468991,
                    pink: 16761035,
                    plum: 14524637,
                    powderblue: 11591910,
                    purple: 8388736,
                    rebeccapurple: 6697881,
                    red: 16711680,
                    rosybrown: 12357519,
                    royalblue: 4286945,
                    saddlebrown: 9127187,
                    salmon: 16416882,
                    sandybrown: 16032864,
                    seagreen: 3050327,
                    seashell: 16774638,
                    sienna: 10506797,
                    silver: 12632256,
                    skyblue: 8900331,
                    slateblue: 6970061,
                    slategray: 7372944,
                    slategrey: 7372944,
                    snow: 16775930,
                    springgreen: 65407,
                    steelblue: 4620980,
                    tan: 13808780,
                    teal: 32896,
                    thistle: 14204888,
                    tomato: 16737095,
                    turquoise: 4251856,
                    violet: 15631086,
                    wheat: 16113331,
                    white: 16777215,
                    whitesmoke: 16119285,
                    yellow: 16776960,
                    yellowgreen: 10145074
                };

            function w() {
                return this.rgb().formatHex()
            }

            function b() {
                return this.rgb().formatRgb()
            }

            function _(t) {
                var n, e;
                return t = (t + "").trim().toLowerCase(), (n = f.exec(t)) ? (e = n[1].length, n = parseInt(n[1], 16), 6 === e ? x(n) : 3 === e ? new N(n >> 8 & 15 | n >> 4 & 240, n >> 4 & 15 | 240 & n, (15 & n) << 4 | 15 & n, 1) : 8 === e ? M(n >> 24 & 255, n >> 16 & 255, n >> 8 & 255, (255 & n) / 255) : 4 === e ? M(n >> 12 & 15 | n >> 8 & 240, n >> 8 & 15 | n >> 4 & 240, n >> 4 & 15 | 240 & n, ((15 & n) << 4 | 15 & n) / 255) : null) : (n = h.exec(t)) ? new N(n[1], n[2], n[3], 1) : (n = p.exec(t)) ? new N(255 * n[1] / 100, 255 * n[2] / 100, 255 * n[3] / 100, 1) : (n = d.exec(t)) ? M(n[1], n[2], n[3], n[4]) : (n = v.exec(t)) ? M(255 * n[1] / 100, 255 * n[2] / 100, 255 * n[3] / 100, n[4]) : (n = g.exec(t)) ? S(n[1], n[2] / 100, n[3] / 100, 1) : (n = y.exec(t)) ? S(n[1], n[2] / 100, n[3] / 100, n[4]) : m.hasOwnProperty(t) ? x(m[t]) : "transparent" === t ? new N(NaN, NaN, NaN, 0) : null
            }

            function x(t) {
                return new N(t >> 16 & 255, t >> 8 & 255, 255 & t, 1)
            }

            function M(t, n, e, r) {
                return r <= 0 && (t = n = e = NaN), new N(t, n, e, r)
            }

            function k(t) {
                return t instanceof a || (t = _(t)), t ? new N((t = t.rgb()).r, t.g, t.b, t.opacity) : new N
            }

            function A(t, n, e, r) {
                return 1 === arguments.length ? k(t) : new N(t, n, e, null == r ? 1 : r)
            }

            function N(t, n, e, r) {
                this.r = +t, this.g = +n, this.b = +e, this.opacity = +r
            }

            function j() {
                return "#" + E(this.r) + E(this.g) + E(this.b)
            }

            function O() {
                var t = this.opacity;
                return (1 === (t = isNaN(t) ? 1 : Math.max(0, Math.min(1, t))) ? "rgb(" : "rgba(") + Math.max(0, Math.min(255, Math.round(this.r) || 0)) + ", " + Math.max(0, Math.min(255, Math.round(this.g) || 0)) + ", " + Math.max(0, Math.min(255, Math.round(this.b) || 0)) + (1 === t ? ")" : ", " + t + ")")
            }

            function E(t) {
                return ((t = Math.max(0, Math.min(255, Math.round(t) || 0))) < 16 ? "0" : "") + t.toString(16)
            }

            function S(t, n, e, r) {
                return r <= 0 ? t = n = e = NaN : e <= 0 || e >= 1 ? t = n = NaN : n <= 0 && (t = NaN), new q(t, n, e, r)
            }

            function C(t) {
                if (t instanceof q) return new q(t.h, t.s, t.l, t.opacity);
                if (t instanceof a || (t = _(t)), !t) return new q;
                if (t instanceof q) return t;
                var n = (t = t.rgb()).r / 255,
                    e = t.g / 255,
                    r = t.b / 255,
                    i = Math.min(n, e, r),
                    o = Math.max(n, e, r),
                    u = NaN,
                    c = o - i,
                    s = (o + i) / 2;
                return c ? (u = n === o ? (e - r) / c + 6 * (e < r) : e === o ? (r - n) / c + 2 : (n - e) / c + 4, c /= s < .5 ? o + i : 2 - o - i, u *= 60) : c = s > 0 && s < 1 ? 0 : u, new q(u, c, s, t.opacity)
            }

            function q(t, n, e, r) {
                this.h = +t, this.s = +n, this.l = +e, this.opacity = +r
            }

            function P(t, n, e) {
                return 255 * (t < 60 ? n + (e - n) * t / 60 : t < 180 ? e : t < 240 ? n + (e - n) * (240 - t) / 60 : n)
            }
            r(a, _, {
                copy: function(t) {
                    return Object.assign(new this.constructor, this, t)
                },
                displayable: function() {
                    return this.rgb().displayable()
                },
                hex: w,
                formatHex: w,
                formatHsl: function() {
                    return C(this).formatHsl()
                },
                formatRgb: b,
                toString: b
            }), r(N, A, i(a, {
                brighter: function(t) {
                    return t = null == t ? u : Math.pow(u, t), new N(this.r * t, this.g * t, this.b * t, this.opacity)
                },
                darker: function(t) {
                    return t = null == t ? o : Math.pow(o, t), new N(this.r * t, this.g * t, this.b * t, this.opacity)
                },
                rgb: function() {
                    return this
                },
                displayable: function() {
                    return -.5 <= this.r && this.r < 255.5 && -.5 <= this.g && this.g < 255.5 && -.5 <= this.b && this.b < 255.5 && 0 <= this.opacity && this.opacity <= 1
                },
                hex: j,
                formatHex: j,
                formatRgb: O,
                toString: O
            })), r(q, (function(t, n, e, r) {
                return 1 === arguments.length ? C(t) : new q(t, n, e, null == r ? 1 : r)
            }), i(a, {
                brighter: function(t) {
                    return t = null == t ? u : Math.pow(u, t), new q(this.h, this.s, this.l * t, this.opacity)
                },
                darker: function(t) {
                    return t = null == t ? o : Math.pow(o, t), new q(this.h, this.s, this.l * t, this.opacity)
                },
                rgb: function() {
                    var t = this.h % 360 + 360 * (this.h < 0),
                        n = isNaN(t) || isNaN(this.s) ? 0 : this.s,
                        e = this.l,
                        r = e + (e < .5 ? e : 1 - e) * n,
                        i = 2 * e - r;
                    return new N(P(t >= 240 ? t - 240 : t + 120, i, r), P(t, i, r), P(t < 120 ? t + 240 : t - 120, i, r), this.opacity)
                },
                displayable: function() {
                    return (0 <= this.s && this.s <= 1 || isNaN(this.s)) && 0 <= this.l && this.l <= 1 && 0 <= this.opacity && this.opacity <= 1
                },
                formatHsl: function() {
                    var t = this.opacity;
                    return (1 === (t = isNaN(t) ? 1 : Math.max(0, Math.min(1, t))) ? "hsl(" : "hsla(") + (this.h || 0) + ", " + 100 * (this.s || 0) + "%, " + 100 * (this.l || 0) + "%" + (1 === t ? ")" : ", " + t + ")")
                }
            }))
        }
    }
]);
//# sourceMappingURL=1.27744010.chunk.js.map