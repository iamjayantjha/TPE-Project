(this.webpackJsonpcovid19india = this.webpackJsonpcovid19india || []).push([
    [35], {
        176: function(e, t, n) {
            "use strict";
            var r = n(2),
                c = n(93),
                i = c.a ? window : null,
                a = function(e) {
                    return !!e.addEventListener
                },
                o = function(e) {
                    return !!e.on
                },
                s = function(e, t, n, s) {
                    void 0 === n && (n = i), Object(r.useEffect)((function() {
                        if (t && n) return a(n) ? Object(c.d)(n, e, t, s) : o(n) && n.on(e, t, s),
                            function() {
                                a(n) ? Object(c.c)(n, e, t, s) : o(n) && n.off(e, t, s)
                            }
                    }), [e, t, n, JSON.stringify(s)])
                },
                u = function(e, t, n, i) {
                    void 0 === t && (t = c.b), void 0 === n && (n = {}), void 0 === i && (i = [e]);
                    var a = n.event,
                        o = void 0 === a ? "keydown" : a,
                        u = n.target,
                        l = n.options,
                        f = Object(r.useMemo)((function() {
                            var n, r = "function" === typeof(n = e) ? n : "string" === typeof n ? function(e) {
                                return e.key === n
                            } : n ? function() {
                                return !0
                            } : function() {
                                return !1
                            };
                            return function(e) {
                                if (r(e)) return t(e)
                            }
                        }), i);
                    s(o, f, u, l)
                },
                l = function(e) {
                    var t = Object(r.useState)([!1, null]),
                        n = t[0],
                        c = t[1];
                    return u(e, (function(e) {
                        return c([!0, e])
                    }), {
                        event: "keydown"
                    }, [n]), u(e, (function(e) {
                        return c([!1, e])
                    }), {
                        event: "keyup"
                    }, [n]), n
                },
                f = n(144);
            t.a = function(e, t, n, r) {
                void 0 === r && (r = l);
                var c = r(e),
                    i = c[0],
                    a = c[1];
                Object(f.a)((function() {
                    !i && n ? n(a) : i && t && t(a)
                }), [i])
            }
        },
        279: function(e, t, n) {
            "use strict";
            n.r(t);
            var r = n(47),
                c = n(10),
                i = n(106),
                a = n(2),
                o = n.n(a),
                s = n(23),
                u = n.n(s);

            function l() {
                return (l = Object.assign || function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = arguments[t];
                        for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r])
                    }
                    return e
                }).apply(this, arguments)
            }

            function f(e, t) {
                if (null == e) return {};
                var n, r, c = function(e, t) {
                    if (null == e) return {};
                    var n, r, c = {},
                        i = Object.keys(e);
                    for (r = 0; r < i.length; r++) n = i[r], t.indexOf(n) >= 0 || (c[n] = e[n]);
                    return c
                }(e, t);
                if (Object.getOwnPropertySymbols) {
                    var i = Object.getOwnPropertySymbols(e);
                    for (r = 0; r < i.length; r++) n = i[r], t.indexOf(n) >= 0 || Object.prototype.propertyIsEnumerable.call(e, n) && (c[n] = e[n])
                }
                return c
            }
            var d = Object(a.forwardRef)((function(e, t) {
                var n = e.color,
                    r = void 0 === n ? "currentColor" : n,
                    c = e.size,
                    i = void 0 === c ? 24 : c,
                    a = f(e, ["color", "size"]);
                return o.a.createElement("svg", l({
                    ref: t,
                    xmlns: "http://www.w3.org/2000/svg",
                    width: i,
                    height: i,
                    viewBox: "0 0 24 24",
                    fill: "none",
                    stroke: r,
                    strokeWidth: "2",
                    strokeLinecap: "round",
                    strokeLinejoin: "round"
                }, a), o.a.createElement("circle", {
                    cx: "11",
                    cy: "11",
                    r: "8"
                }), o.a.createElement("line", {
                    x1: "21",
                    y1: "21",
                    x2: "16.65",
                    y2: "16.65"
                }))
            }));
            d.propTypes = {
                color: u.a.string,
                size: u.a.oneOfType([u.a.string, u.a.number])
            }, d.displayName = "Search";
            var b = d;

            function j() {
                return (j = Object.assign || function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = arguments[t];
                        for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r])
                    }
                    return e
                }).apply(this, arguments)
            }

            function p(e, t) {
                if (null == e) return {};
                var n, r, c = function(e, t) {
                    if (null == e) return {};
                    var n, r, c = {},
                        i = Object.keys(e);
                    for (r = 0; r < i.length; r++) n = i[r], t.indexOf(n) >= 0 || (c[n] = e[n]);
                    return c
                }(e, t);
                if (Object.getOwnPropertySymbols) {
                    var i = Object.getOwnPropertySymbols(e);
                    for (r = 0; r < i.length; r++) n = i[r], t.indexOf(n) >= 0 || Object.prototype.propertyIsEnumerable.call(e, n) && (c[n] = e[n])
                }
                return c
            }
            var O = Object(a.forwardRef)((function(e, t) {
                var n = e.color,
                    r = void 0 === n ? "currentColor" : n,
                    c = e.size,
                    i = void 0 === c ? 24 : c,
                    a = p(e, ["color", "size"]);
                return o.a.createElement("svg", j({
                    ref: t,
                    xmlns: "http://www.w3.org/2000/svg",
                    width: i,
                    height: i,
                    viewBox: "0 0 24 24",
                    fill: "none",
                    stroke: r,
                    strokeWidth: "2",
                    strokeLinecap: "round",
                    strokeLinejoin: "round"
                }, a), o.a.createElement("line", {
                    x1: "18",
                    y1: "6",
                    x2: "6",
                    y2: "18"
                }), o.a.createElement("line", {
                    x1: "6",
                    y1: "6",
                    x2: "18",
                    y2: "18"
                }))
            }));
            O.propTypes = {
                color: u.a.string,
                size: u.a.oneOfType([u.a.string, u.a.number])
            }, O.displayName = "X";
            var v = O;

            function h() {
                return (h = Object.assign || function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = arguments[t];
                        for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r])
                    }
                    return e
                }).apply(this, arguments)
            }

            function m(e, t) {
                if (null == e) return {};
                var n, r, c = function(e, t) {
                    if (null == e) return {};
                    var n, r, c = {},
                        i = Object.keys(e);
                    for (r = 0; r < i.length; r++) n = i[r], t.indexOf(n) >= 0 || (c[n] = e[n]);
                    return c
                }(e, t);
                if (Object.getOwnPropertySymbols) {
                    var i = Object.getOwnPropertySymbols(e);
                    for (r = 0; r < i.length; r++) n = i[r], t.indexOf(n) >= 0 || Object.prototype.propertyIsEnumerable.call(e, n) && (c[n] = e[n])
                }
                return c
            }
            var y = Object(a.forwardRef)((function(e, t) {
                var n = e.color,
                    r = void 0 === n ? "currentColor" : n,
                    c = e.size,
                    i = void 0 === c ? 24 : c,
                    a = m(e, ["color", "size"]);
                return o.a.createElement("svg", h({
                    ref: t,
                    xmlns: "http://www.w3.org/2000/svg",
                    width: i,
                    height: i,
                    viewBox: "0 0 24 24",
                    fill: "none",
                    stroke: r,
                    strokeWidth: "2",
                    strokeLinecap: "round",
                    strokeLinejoin: "round"
                }, a), o.a.createElement("circle", {
                    cx: "12",
                    cy: "12",
                    r: "10"
                }), o.a.createElement("polyline", {
                    points: "12 16 16 12 12 8"
                }), o.a.createElement("line", {
                    x1: "8",
                    y1: "12",
                    x2: "16",
                    y2: "12"
                }))
            }));
            y.propTypes = {
                color: u.a.string,
                size: u.a.oneOfType([u.a.string, u.a.number])
            }, y.displayName = "ArrowRightCircle";
            var x = y,
                g = n(288),
                w = n(48),
                k = n(144);

            function E(e, t, n) {
                void 0 === t && (t = 0), void 0 === n && (n = []);
                var r = function(e, t) {
                        void 0 === t && (t = 0);
                        var n = Object(a.useRef)(!1),
                            r = Object(a.useRef)(),
                            c = Object(a.useRef)(e),
                            i = Object(a.useCallback)((function() {
                                return n.current
                            }), []),
                            o = Object(a.useCallback)((function() {
                                n.current = !1, r.current && clearTimeout(r.current), r.current = setTimeout((function() {
                                    n.current = !0, c.current()
                                }), t)
                            }), [t]),
                            s = Object(a.useCallback)((function() {
                                n.current = null, r.current && clearTimeout(r.current)
                            }), []);
                        return Object(a.useEffect)((function() {
                            c.current = e
                        }), [e]), Object(a.useEffect)((function() {
                            return o(), s
                        }), [t]), [i, s, o]
                    }(e, t),
                    c = r[0],
                    i = r[1],
                    o = r[2];
                return Object(a.useEffect)(o, n), [c, i]
            }
            var N = n(176),
                C = n(19),
                z = ["Madurai", "Karnataka", "Ladakh", "Mumbai", "Andhra Pradesh", "Alappuzha"],
                S = ["Madurai", "Ganjam", "Alappuzha", "Mumbai", "Chennai"],
                T = ["Andhra Pradesh", "Karnataka", "Gujarat", "West Bengal", "Ladakh"];

            function P() {
                var e = Object(a.useState)(""),
                    t = Object(r.a)(e, 2),
                    o = t[0],
                    s = t[1],
                    u = Object(a.useState)(!1),
                    l = Object(r.a)(u, 2),
                    f = l[0],
                    d = l[1],
                    j = Object(a.useState)([]),
                    p = Object(r.a)(j, 2),
                    O = p[0],
                    h = p[1],
                    m = Object(a.useRef)(null),
                    y = Object(g.a)().t,
                    P = Object(a.useState)(null),
                    L = Object(r.a)(P, 2),
                    D = L[0],
                    R = L[1],
                    M = Object(a.useState)(null),
                    B = Object(r.a)(M, 2),
                    I = B[0],
                    A = B[1];
                Object(k.a)((function() {
                    n.e(26).then(n.t.bind(null, 268, 7)).then((function(e) {
                        R(new e.default({
                            initialize: !0,
                            local: c.x.filter((function(e) {
                                return e.code !== c.G
                            })),
                            queryTokenizer: e.default.tokenizers.whitespace,
                            datumTokenizer: e.default.tokenizers.obj.whitespace("name")
                        })), A(new e.default({
                            initialize: !0,
                            limit: 5,
                            queryTokenizer: e.default.tokenizers.whitespace,
                            datumTokenizer: e.default.tokenizers.obj.whitespace("district"),
                            indexRemote: !0,
                            remote: {
                                url: "".concat(c.a, "/state_district_wise.json"),
                                transform: function(e) {
                                    var t = [];
                                    return Object.keys(e).filter((function(e) {
                                        return "State Unassigned" !== e
                                    })).map((function(n) {
                                        var r = e[n].districtData;
                                        return Object.keys(r).filter((function(e) {
                                            return e !== c.H
                                        })).map((function(e) {
                                            return t.push({
                                                district: e,
                                                state: n
                                            })
                                        })), null
                                    })), t
                                }
                            }
                        }))
                    }))
                }), [f]);
                var U = Object(a.useCallback)((function(e) {
                    if (!D) return null;
                    var t = [];
                    D.search(e, (function(e) {
                        e.map((function(e, n) {
                            var r = {
                                name: e.name,
                                type: "state",
                                route: e.code
                            };
                            return t.push(r), null
                        }))
                    })), I.search(e, (function(e) {
                        e.slice(0, 3).map((function(e, n) {
                            var r = {
                                name: e.district,
                                type: "district",
                                route: c.w[e.state]
                            };
                            return t.push(r), null
                        })), h([].concat(t))
                    }))
                }), [I, D]);

                function W(e, t) {
                    var n = Object.getOwnPropertyDescriptor(e, "value").set,
                        r = Object.getPrototypeOf(e),
                        c = Object.getOwnPropertyDescriptor(r, "value").set;
                    n && n !== c ? c.call(e, t) : n.call(e, t)
                }
                E((function() {
                    o ? U(o) : h(Object(i.a)(O, (function(e) {
                        e.splice(0)
                    })))
                }), 100, [o]);
                var G = Object(a.useCallback)((function(e, t, n, r) {
                        if (f) return e.textContent = "", !0;
                        var c = y(z[t]),
                            i = e.textContent;
                        if (e.classList.remove("disappear"), e.textContent = i + c[n], n < c.length - 1) return setTimeout((function() {
                            G(e, t, n + 1, r)
                        }), 200), !0;
                        r()
                    }), [f, y]),
                    J = Object(a.useCallback)((function(e, t) {
                        var n = e.textContent;
                        if (e.classList.add("disappear"), n.length > 0) return setTimeout((function() {
                            e.textContent = "", J(e, t)
                        }), 1e3), !0;
                        t()
                    }), []),
                    q = Object(a.useCallback)((function(e, t) {
                        if (f) return e.textContent = "", !0;
                        G(e, t, 0, (function() {
                            setTimeout((function() {
                                J(e, (function() {
                                    q(e, (t + 1) % z.length)
                                }))
                            }), 2e3)
                        }))
                    }), [J, f, G]);
                Object(a.useEffect)((function() {
                    if (!f) {
                        var e = document.getElementsByClassName("search-placeholder")[0];
                        e && q(e, 0)
                    }
                }), [f, q]);
                var F = Object(a.useMemo)((function() {
                        var e = [];
                        return [0, 0, 0].map((function(t, n) {
                            return e.push({
                                animationDelay: "".concat(250 * n, "ms")
                            }), null
                        })), e
                    }), []),
                    K = Object(a.useCallback)((function() {
                        s(""), h([])
                    }), []),
                    _ = Object(a.useCallback)((function(e) {
                        s(e.target.value)
                    }), []);
                return Object(N.a)("/", (function() {
                    m.current.focus()
                })), Object(N.a)("Escape", (function() {
                    K(), m.current.blur()
                })), Object(C.jsxs)("div", {
                    className: "Search",
                    children: [Object(C.jsx)("label", {
                        className: "fadeInUp",
                        style: F[0],
                        children: y("Search your district or state")
                    }), Object(C.jsx)("div", {
                        className: "line fadeInUp",
                        style: F[1]
                    }), Object(C.jsxs)("div", {
                        className: "search-input-wrapper fadeInUp",
                        style: F[2],
                        children: [Object(C.jsx)("input", {
                            type: "text",
                            value: o,
                            ref: m,
                            onFocus: d.bind(this, !0),
                            onBlur: d.bind(this, !1),
                            onChange: _
                        }), !f && "" === o && Object(C.jsx)("span", {
                            className: "search-placeholder"
                        }), Object(C.jsx)("div", {
                            className: "search-button",
                            children: Object(C.jsx)(b, {})
                        }), o.length > 0 && Object(C.jsx)("div", {
                            className: "close-button",
                            onClick: K,
                            children: Object(C.jsx)(v, {})
                        })]
                    }), O.length > 0 && Object(C.jsx)("div", {
                        className: "results",
                        children: O.map((function(e, t) {
                            return Object(C.jsx)(w.b, {
                                to: "state/".concat(e.route),
                                children: Object(C.jsxs)("div", {
                                    className: "result",
                                    children: [Object(C.jsx)("div", {
                                        className: "result-left",
                                        children: Object(C.jsxs)("div", {
                                            className: "result-name",
                                            children: ["".concat(e.name), "district" === e.type && ", ".concat(c.y[e.route])]
                                        })
                                    }), Object(C.jsxs)("div", {
                                        className: "result-type",
                                        children: [Object(C.jsx)("span", {
                                            children: [e.route]
                                        }), Object(C.jsx)(x, {
                                            size: 14
                                        })]
                                    })]
                                })
                            }, t)
                        }))
                    }), f && Object(C.jsx)(C.Fragment, {
                        children: Object(C.jsxs)("div", {
                            className: "expanded",
                            children: [Object(C.jsxs)("div", {
                                className: "expanded-left",
                                children: [Object(C.jsx)("h3", {
                                    children: y("District")
                                }), Object(C.jsx)("div", {
                                    className: "suggestions",
                                    children: S.map((function(e, t) {
                                        return Object(C.jsxs)("div", {
                                            className: "suggestion",
                                            children: [Object(C.jsx)("div", {
                                                children: "-"
                                            }), Object(C.jsx)("h4", {
                                                onMouseDown: function(t) {
                                                    t.preventDefault(), W(m.current, e), m.current.dispatchEvent(new Event("input", {
                                                        bubbles: !0
                                                    }))
                                                },
                                                children: y(e)
                                            })]
                                        }, t)
                                    }))
                                })]
                            }), Object(C.jsxs)("div", {
                                className: "expanded-right",
                                children: [Object(C.jsx)("h3", {
                                    children: y("State/UT")
                                }), Object(C.jsx)("div", {
                                    className: "suggestions",
                                    children: T.map((function(e, t) {
                                        return Object(C.jsxs)("div", {
                                            className: "suggestion",
                                            children: [Object(C.jsx)("div", {
                                                children: "-"
                                            }), Object(C.jsx)("h4", {
                                                onMouseDown: function(t) {
                                                    t.preventDefault(), W(m.current, e), m.current.dispatchEvent(new Event("input", {
                                                        bubbles: !0
                                                    }))
                                                },
                                                children: y(e)
                                            })]
                                        }, t)
                                    }))
                                })]
                            })]
                        })
                    })]
                })
            }
            var L = function() {
                return !0
            };
            t.default = Object(a.memo)(P, L)
        }
    }
]);
//# sourceMappingURL=35.06939100.chunk.js.map