var addMethods = require("../../node_modules/workerize-loader/dist/rpc-wrapper.js")
var methods = ["getDistricts"]
module.exports = function() {
    var w = new Worker(__webpack_public_path__ + "ece08537062c28a2a7c1.worker.js", {
        name: "[hash].worker.js"
    })
    addMethods(w, methods)

    return w
}