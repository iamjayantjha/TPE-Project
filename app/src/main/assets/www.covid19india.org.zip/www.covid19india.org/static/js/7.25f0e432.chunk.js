(this.webpackJsonpcovid19india = this.webpackJsonpcovid19india || []).push([
    [7], {
        105: function(e, t, r) {
            "use strict";
            var n = r(2),
                o = function() {
                    return (o = Object.assign || function(e) {
                        for (var t, r = 1, n = arguments.length; r < n; r++)
                            for (var o in t = arguments[r]) Object.prototype.hasOwnProperty.call(t, o) && (e[o] = t[o]);
                        return e
                    }).apply(this, arguments)
                };
            var i = function(e) {
                var t = e.animate,
                    r = e.backgroundColor,
                    i = e.backgroundOpacity,
                    c = e.baseUrl,
                    u = e.children,
                    a = e.foregroundColor,
                    f = e.foregroundOpacity,
                    l = e.gradientRatio,
                    s = e.uniqueKey,
                    p = e.interval,
                    y = e.rtl,
                    d = e.speed,
                    b = e.style,
                    h = e.title,
                    v = function(e, t) {
                        var r = {};
                        for (var n in e) Object.prototype.hasOwnProperty.call(e, n) && t.indexOf(n) < 0 && (r[n] = e[n]);
                        if (null != e && "function" === typeof Object.getOwnPropertySymbols) {
                            var o = 0;
                            for (n = Object.getOwnPropertySymbols(e); o < n.length; o++) t.indexOf(n[o]) < 0 && Object.prototype.propertyIsEnumerable.call(e, n[o]) && (r[n[o]] = e[n[o]])
                        }
                        return r
                    }(e, ["animate", "backgroundColor", "backgroundOpacity", "baseUrl", "children", "foregroundColor", "foregroundOpacity", "gradientRatio", "uniqueKey", "interval", "rtl", "speed", "style", "title"]),
                    O = s || Math.random().toString(36).substring(6),
                    m = O + "-diff",
                    g = O + "-animated-diff",
                    j = O + "-aria",
                    P = y ? {
                        transform: "scaleX(-1)"
                    } : null,
                    w = "0; " + p + "; 1",
                    E = d + "s";
                return Object(n.createElement)("svg", o({
                    "aria-labelledby": j,
                    role: "img",
                    style: o(o({}, b), P)
                }, v), h ? Object(n.createElement)("title", {
                    id: j
                }, h) : null, Object(n.createElement)("rect", {
                    role: "presentation",
                    x: "0",
                    y: "0",
                    width: "100%",
                    height: "100%",
                    clipPath: "url(" + c + "#" + m + ")",
                    style: {
                        fill: "url(" + c + "#" + g + ")"
                    }
                }), Object(n.createElement)("defs", null, Object(n.createElement)("clipPath", {
                    id: m
                }, u), Object(n.createElement)("linearGradient", {
                    id: g
                }, Object(n.createElement)("stop", {
                    offset: "0%",
                    stopColor: r,
                    stopOpacity: i
                }, t && Object(n.createElement)("animate", {
                    attributeName: "offset",
                    values: -l + "; " + -l + "; 1",
                    keyTimes: w,
                    dur: E,
                    repeatCount: "indefinite"
                })), Object(n.createElement)("stop", {
                    offset: "50%",
                    stopColor: a,
                    stopOpacity: f
                }, t && Object(n.createElement)("animate", {
                    attributeName: "offset",
                    values: -l / 2 + "; " + -l / 2 + "; " + (1 + l / 2),
                    keyTimes: w,
                    dur: E,
                    repeatCount: "indefinite"
                })), Object(n.createElement)("stop", {
                    offset: "100%",
                    stopColor: r,
                    stopOpacity: i
                }, t && Object(n.createElement)("animate", {
                    attributeName: "offset",
                    values: "0; 0; " + (1 + l),
                    keyTimes: w,
                    dur: E,
                    repeatCount: "indefinite"
                })))))
            };
            i.defaultProps = {
                animate: !0,
                backgroundColor: "#f5f6f7",
                backgroundOpacity: 1,
                baseUrl: "",
                foregroundColor: "#eee",
                foregroundOpacity: 1,
                gradientRatio: 2,
                id: null,
                interval: .25,
                rtl: !1,
                speed: 1.2,
                style: {},
                title: "Loading..."
            };
            var c = function(e) {
                    return e.children ? Object(n.createElement)(i, o({}, e)) : Object(n.createElement)(u, o({}, e))
                },
                u = function(e) {
                    return Object(n.createElement)(c, o({
                        viewBox: "0 0 476 124"
                    }, e), Object(n.createElement)("rect", {
                        x: "48",
                        y: "8",
                        width: "88",
                        height: "6",
                        rx: "3"
                    }), Object(n.createElement)("rect", {
                        x: "48",
                        y: "26",
                        width: "52",
                        height: "6",
                        rx: "3"
                    }), Object(n.createElement)("rect", {
                        x: "0",
                        y: "56",
                        width: "410",
                        height: "6",
                        rx: "3"
                    }), Object(n.createElement)("rect", {
                        x: "0",
                        y: "72",
                        width: "380",
                        height: "6",
                        rx: "3"
                    }), Object(n.createElement)("rect", {
                        x: "0",
                        y: "88",
                        width: "178",
                        height: "6",
                        rx: "3"
                    }), Object(n.createElement)("circle", {
                        cx: "20",
                        cy: "20",
                        r: "20"
                    }))
                };
            t.a = c
        },
        106: function(e, t, r) {
            "use strict";

            function n(e) {
                for (var t = arguments.length, r = Array(t > 1 ? t - 1 : 0), n = 1; n < t; n++) r[n - 1] = arguments[n];
                throw Error("[Immer] minified error nr: " + e + (r.length ? " " + r.map((function(e) {
                    return "'" + e + "'"
                })).join(",") : "") + ". Find the full error at: https://bit.ly/3cXEKWf")
            }

            function o(e) {
                return !!e && !!e[L]
            }

            function i(e) {
                return !!e && (function(e) {
                    if (!e || "object" != typeof e) return !1;
                    var t = Object.getPrototypeOf(e);
                    if (null === t) return !0;
                    var r = Object.hasOwnProperty.call(t, "constructor") && t.constructor;
                    return r === Object || "function" == typeof r && Function.toString.call(r) === X
                }(e) || Array.isArray(e) || !!e[q] || !!e.constructor[q] || p(e) || y(e))
            }

            function c(e, t, r) {
                void 0 === r && (r = !1), 0 === u(e) ? (r ? Object.keys : B)(e).forEach((function(n) {
                    r && "symbol" == typeof n || t(n, e[n], e)
                })) : e.forEach((function(r, n) {
                    return t(n, r, e)
                }))
            }

            function u(e) {
                var t = e[L];
                return t ? t.i > 3 ? t.i - 4 : t.i : Array.isArray(e) ? 1 : p(e) ? 2 : y(e) ? 3 : 0
            }

            function a(e, t) {
                return 2 === u(e) ? e.has(t) : Object.prototype.hasOwnProperty.call(e, t)
            }

            function f(e, t) {
                return 2 === u(e) ? e.get(t) : e[t]
            }

            function l(e, t, r) {
                var n = u(e);
                2 === n ? e.set(t, r) : 3 === n ? (e.delete(t), e.add(r)) : e[t] = r
            }

            function s(e, t) {
                return e === t ? 0 !== e || 1 / e == 1 / t : e != e && t != t
            }

            function p(e) {
                return T && e instanceof Map
            }

            function y(e) {
                return W && e instanceof Set
            }

            function d(e) {
                return e.o || e.t
            }

            function b(e) {
                if (Array.isArray(e)) return Array.prototype.slice.call(e);
                var t = G(e);
                delete t[L];
                for (var r = B(t), n = 0; n < r.length; n++) {
                    var o = r[n],
                        i = t[o];
                    !1 === i.writable && (i.writable = !0, i.configurable = !0), (i.get || i.set) && (t[o] = {
                        configurable: !0,
                        writable: !0,
                        enumerable: i.enumerable,
                        value: e[o]
                    })
                }
                return Object.create(Object.getPrototypeOf(e), t)
            }

            function h(e, t) {
                return void 0 === t && (t = !1), O(e) || o(e) || !i(e) || (u(e) > 1 && (e.set = e.add = e.clear = e.delete = v), Object.freeze(e), t && c(e, (function(e, t) {
                    return h(t, !0)
                }), !0)), e
            }

            function v() {
                n(2)
            }

            function O(e) {
                return null == e || "object" != typeof e || Object.isFrozen(e)
            }

            function m(e) {
                var t = H[e];
                return t || n(18, e), t
            }

            function g() {
                return N
            }

            function j(e, t) {
                t && (m("Patches"), e.u = [], e.s = [], e.v = t)
            }

            function P(e) {
                w(e), e.p.forEach(x), e.p = null
            }

            function w(e) {
                e === N && (N = e.l)
            }

            function E(e) {
                return N = {
                    p: [],
                    l: N,
                    h: e,
                    m: !0,
                    _: 0
                }
            }

            function x(e) {
                var t = e[L];
                0 === t.i || 1 === t.i ? t.j() : t.O = !0
            }

            function S(e, t) {
                t._ = t.p.length;
                var r = t.p[0],
                    o = void 0 !== e && e !== r;
                return t.h.g || m("ES5").S(t, e, o), o ? (r[L].P && (P(t), n(4)), i(e) && (e = A(t, e), t.l || D(t, e)), t.u && m("Patches").M(r[L], e, t.u, t.s)) : e = A(t, r, []), P(t), t.u && t.v(t.u, t.s), e !== $ ? e : void 0
            }

            function A(e, t, r) {
                if (O(t)) return t;
                var n = t[L];
                if (!n) return c(t, (function(o, i) {
                    return k(e, n, t, o, i, r)
                }), !0), t;
                if (n.A !== e) return t;
                if (!n.P) return D(e, n.t, !0), n.t;
                if (!n.I) {
                    n.I = !0, n.A._--;
                    var o = 4 === n.i || 5 === n.i ? n.o = b(n.k) : n.o;
                    c(3 === n.i ? new Set(o) : o, (function(t, i) {
                        return k(e, n, o, t, i, r)
                    })), D(e, o, !1), r && e.u && m("Patches").R(n, r, e.u, e.s)
                }
                return n.o
            }

            function k(e, t, r, n, c, u) {
                if (o(c)) {
                    var f = A(e, c, u && t && 3 !== t.i && !a(t.D, n) ? u.concat(n) : void 0);
                    if (l(r, n, f), !o(f)) return;
                    e.m = !1
                }
                if (i(c) && !O(c)) {
                    if (!e.h.F && e._ < 1) return;
                    A(e, c), t && t.A.l || D(e, c)
                }
            }

            function D(e, t, r) {
                void 0 === r && (r = !1), e.h.F && e.m && h(t, r)
            }

            function C(e, t) {
                var r = e[L];
                return (r ? d(r) : e)[t]
            }

            function F(e, t) {
                if (t in e)
                    for (var r = Object.getPrototypeOf(e); r;) {
                        var n = Object.getOwnPropertyDescriptor(r, t);
                        if (n) return n;
                        r = Object.getPrototypeOf(r)
                    }
            }

            function R(e) {
                e.P || (e.P = !0, e.l && R(e.l))
            }

            function _(e) {
                e.o || (e.o = b(e.t))
            }

            function z(e, t, r) {
                var n = p(t) ? m("MapSet").N(t, r) : y(t) ? m("MapSet").T(t, r) : e.g ? function(e, t) {
                    var r = Array.isArray(e),
                        n = {
                            i: r ? 1 : 0,
                            A: t ? t.A : g(),
                            P: !1,
                            I: !1,
                            D: {},
                            l: t,
                            t: e,
                            k: null,
                            o: null,
                            j: null,
                            C: !1
                        },
                        o = n,
                        i = Q;
                    r && (o = [n], i = V);
                    var c = Proxy.revocable(o, i),
                        u = c.revoke,
                        a = c.proxy;
                    return n.k = a, n.j = u, a
                }(t, r) : m("ES5").J(t, r);
                return (r ? r.A : g()).p.push(n), n
            }

            function I(e) {
                return o(e) || n(22, e),
                    function e(t) {
                        if (!i(t)) return t;
                        var r, n = t[L],
                            o = u(t);
                        if (n) {
                            if (!n.P && (n.i < 4 || !m("ES5").K(n))) return n.t;
                            n.I = !0, r = K(t, o), n.I = !1
                        } else r = K(t, o);
                        return c(r, (function(t, o) {
                            n && f(n.t, t) === o || l(r, t, e(o))
                        })), 3 === o ? new Set(r) : r
                    }(e)
            }

            function K(e, t) {
                switch (t) {
                    case 2:
                        return new Map(e);
                    case 3:
                        return Array.from(e)
                }
                return b(e)
            }
            var M, N, U = "undefined" != typeof Symbol && "symbol" == typeof Symbol("x"),
                T = "undefined" != typeof Map,
                W = "undefined" != typeof Set,
                J = "undefined" != typeof Proxy && void 0 !== Proxy.revocable && "undefined" != typeof Reflect,
                $ = U ? Symbol.for("immer-nothing") : ((M = {})["immer-nothing"] = !0, M),
                q = U ? Symbol.for("immer-draftable") : "__$immer_draftable",
                L = U ? Symbol.for("immer-state") : "__$immer_state",
                X = ("undefined" != typeof Symbol && Symbol.iterator, "" + Object.prototype.constructor),
                B = "undefined" != typeof Reflect && Reflect.ownKeys ? Reflect.ownKeys : void 0 !== Object.getOwnPropertySymbols ? function(e) {
                    return Object.getOwnPropertyNames(e).concat(Object.getOwnPropertySymbols(e))
                } : Object.getOwnPropertyNames,
                G = Object.getOwnPropertyDescriptors || function(e) {
                    var t = {};
                    return B(e).forEach((function(r) {
                        t[r] = Object.getOwnPropertyDescriptor(e, r)
                    })), t
                },
                H = {},
                Q = {
                    get: function(e, t) {
                        if (t === L) return e;
                        var r = d(e);
                        if (!a(r, t)) return function(e, t, r) {
                            var n, o = F(t, r);
                            return o ? "value" in o ? o.value : null === (n = o.get) || void 0 === n ? void 0 : n.call(e.k) : void 0
                        }(e, r, t);
                        var n = r[t];
                        return e.I || !i(n) ? n : n === C(e.t, t) ? (_(e), e.o[t] = z(e.A.h, n, e)) : n
                    },
                    has: function(e, t) {
                        return t in d(e)
                    },
                    ownKeys: function(e) {
                        return Reflect.ownKeys(d(e))
                    },
                    set: function(e, t, r) {
                        var n = F(d(e), t);
                        if (null == n ? void 0 : n.set) return n.set.call(e.k, r), !0;
                        if (!e.P) {
                            var o = C(d(e), t),
                                i = null == o ? void 0 : o[L];
                            if (i && i.t === r) return e.o[t] = r, e.D[t] = !1, !0;
                            if (s(r, o) && (void 0 !== r || a(e.t, t))) return !0;
                            _(e), R(e)
                        }
                        return e.o[t] === r && "number" != typeof r || (e.o[t] = r, e.D[t] = !0, !0)
                    },
                    deleteProperty: function(e, t) {
                        return void 0 !== C(e.t, t) || t in e.t ? (e.D[t] = !1, _(e), R(e)) : delete e.D[t], e.o && delete e.o[t], !0
                    },
                    getOwnPropertyDescriptor: function(e, t) {
                        var r = d(e),
                            n = Reflect.getOwnPropertyDescriptor(r, t);
                        return n ? {
                            writable: !0,
                            configurable: 1 !== e.i || "length" !== t,
                            enumerable: n.enumerable,
                            value: r[t]
                        } : n
                    },
                    defineProperty: function() {
                        n(11)
                    },
                    getPrototypeOf: function(e) {
                        return Object.getPrototypeOf(e.t)
                    },
                    setPrototypeOf: function() {
                        n(12)
                    }
                },
                V = {};
            c(Q, (function(e, t) {
                V[e] = function() {
                    return arguments[0] = arguments[0][0], t.apply(this, arguments)
                }
            })), V.deleteProperty = function(e, t) {
                return Q.deleteProperty.call(this, e[0], t)
            }, V.set = function(e, t, r) {
                return Q.set.call(this, e[0], t, r, e[0])
            };
            var Y = new(function() {
                    function e(e) {
                        var t = this;
                        this.g = J, this.F = !0, this.produce = function(e, r, o) {
                            if ("function" == typeof e && "function" != typeof r) {
                                var c = r;
                                r = e;
                                var u = t;
                                return function(e) {
                                    var t = this;
                                    void 0 === e && (e = c);
                                    for (var n = arguments.length, o = Array(n > 1 ? n - 1 : 0), i = 1; i < n; i++) o[i - 1] = arguments[i];
                                    return u.produce(e, (function(e) {
                                        var n;
                                        return (n = r).call.apply(n, [t, e].concat(o))
                                    }))
                                }
                            }
                            var a;
                            if ("function" != typeof r && n(6), void 0 !== o && "function" != typeof o && n(7), i(e)) {
                                var f = E(t),
                                    l = z(t, e, void 0),
                                    s = !0;
                                try {
                                    a = r(l), s = !1
                                } finally {
                                    s ? P(f) : w(f)
                                }
                                return "undefined" != typeof Promise && a instanceof Promise ? a.then((function(e) {
                                    return j(f, o), S(e, f)
                                }), (function(e) {
                                    throw P(f), e
                                })) : (j(f, o), S(a, f))
                            }
                            if (!e || "object" != typeof e) {
                                if ((a = r(e)) === $) return;
                                return void 0 === a && (a = e), t.F && h(a, !0), a
                            }
                            n(21, e)
                        }, this.produceWithPatches = function(e, r) {
                            return "function" == typeof e ? function(r) {
                                for (var n = arguments.length, o = Array(n > 1 ? n - 1 : 0), i = 1; i < n; i++) o[i - 1] = arguments[i];
                                return t.produceWithPatches(r, (function(t) {
                                    return e.apply(void 0, [t].concat(o))
                                }))
                            } : [t.produce(e, r, (function(e, t) {
                                n = e, o = t
                            })), n, o];
                            var n, o
                        }, "boolean" == typeof(null == e ? void 0 : e.useProxies) && this.setUseProxies(e.useProxies), "boolean" == typeof(null == e ? void 0 : e.autoFreeze) && this.setAutoFreeze(e.autoFreeze)
                    }
                    var t = e.prototype;
                    return t.createDraft = function(e) {
                        i(e) || n(8), o(e) && (e = I(e));
                        var t = E(this),
                            r = z(this, e, void 0);
                        return r[L].C = !0, w(t), r
                    }, t.finishDraft = function(e, t) {
                        var r = (e && e[L]).A;
                        return j(r, t), S(void 0, r)
                    }, t.setAutoFreeze = function(e) {
                        this.F = e
                    }, t.setUseProxies = function(e) {
                        e && !J && n(20), this.g = e
                    }, t.applyPatches = function(e, t) {
                        var r;
                        for (r = t.length - 1; r >= 0; r--) {
                            var n = t[r];
                            if (0 === n.path.length && "replace" === n.op) {
                                e = n.value;
                                break
                            }
                        }
                        var i = m("Patches").$;
                        return o(e) ? i(e, t) : this.produce(e, (function(e) {
                            return i(e, t.slice(r + 1))
                        }))
                    }, e
                }()),
                Z = Y.produce;
            Y.produceWithPatches.bind(Y), Y.setAutoFreeze.bind(Y), Y.setUseProxies.bind(Y), Y.applyPatches.bind(Y), Y.createDraft.bind(Y), Y.finishDraft.bind(Y);
            t.a = Z
        },
        116: function(e, t, r) {
            "use strict";
            var n = r(2),
                o = r(93),
                i = o.a ? n.useLayoutEffect : n.useEffect,
                c = {
                    x: 0,
                    y: 0,
                    width: 0,
                    height: 0,
                    top: 0,
                    left: 0,
                    bottom: 0,
                    right: 0
                };
            t.a = o.a && "undefined" !== typeof window.ResizeObserver ? function() {
                var e = Object(n.useState)(null),
                    t = e[0],
                    r = e[1],
                    o = Object(n.useState)(c),
                    u = o[0],
                    a = o[1],
                    f = Object(n.useMemo)((function() {
                        return new window.ResizeObserver((function(e) {
                            if (e[0]) {
                                var t = e[0].contentRect,
                                    r = t.x,
                                    n = t.y,
                                    o = t.width,
                                    i = t.height,
                                    c = t.top,
                                    u = t.left,
                                    f = t.bottom,
                                    l = t.right;
                                a({
                                    x: r,
                                    y: n,
                                    width: o,
                                    height: i,
                                    top: c,
                                    left: u,
                                    bottom: f,
                                    right: l
                                })
                            }
                        }))
                    }), []);
                return i((function() {
                    if (t) return f.observe(t),
                        function() {
                            f.disconnect()
                        }
                }), [t]), [r, u]
            } : function() {
                return [o.b, c]
            }
        }
    }
]);
//# sourceMappingURL=7.25f0e432.chunk.js.map